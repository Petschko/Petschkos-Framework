<?php
/**
 * Author: Peter Dragicevic [peter-91@hotmail.de]
 * Authors-Website: http://petschko.org/
 * Licence: http://creativecommons.org/licenses/by-sa/4.0/
 * Date: 14.07.2015
 * Time: 10:38
 * Update: 09.04.2016
 * Version: 1.0.7 (Changed Class-Name & Website)
 *
 * Notice: -
 */

// Initials this class on include - disable these lines if you want to check UserData by yourself
header('Content-Type: text/html; charset=utf-8');
mb_internal_encoding('UTF-8');
new utf8();
// ------------------------------

/**
 * Class Utf8
 *
 * Single-Instance-Class
 */
class Utf8 {
	private static $init = false; // Don't touch!
	// Setup stuff here
	private static $useEntities = false; // Use HTML-Entities instead of HTML-SpecialCharacters (Config does not affect, if check is turned off)
	private static $checkUserInput = true; // Pre-check User-Input (Recommend!)

	/**
	 * Initial this Single-Instance Class and pre-checks/Escape all User-Input-Fields
	 */
	public function __construct() {
		if(! self::isInit()) {
			// Check if all MultiByte (mb) functions are available
			self::checkMultiByteFunctions();

			// Check User-Data?
			if(self::isCheckUserInput()) {

				if(self::isUseEntities()) {
					// Remove unknown chars from User-Data and convert html chars to HTML-Entities
					$_POST = self::arr_htmlentities(self::arr_removeNonUtf8($_POST));
					$_GET = self::arr_htmlentities(self::arr_removeNonUtf8($_GET));
					$_SERVER = self::arr_htmlentities(self::arr_removeNonUtf8($_SERVER));
					$_REQUEST = self::arr_htmlentities(self::arr_removeNonUtf8($_REQUEST));
					$_FILES = self::arr_htmlentities(self::arr_removeNonUtf8($_FILES));

					// Cookies
					if(! class_exists('cookie'))
						$_COOKIE = self::arr_htmlentities(self::arr_removeNonUtf8($_COOKIE));
					else if(cookie::getIsAllowed())
						$_COOKIE = self::arr_htmlentities(self::arr_removeNonUtf8($_COOKIE));
					else {
						// Anyway check Master-Cookie
						if(! isset($_COOKIE[cookie::getMasterCookieName()]))
							$_COOKIE[cookie::getMasterCookieName()] = '';

						$_COOKIE[cookie::getMasterCookieName()] = self::htmlentities(self::removeNonUtf8($_COOKIE[cookie::getMasterCookieName()]));
					}

				} else {
					// Remove unknown chars from User-Data and convert html chars to HTML-SpecialCharacters
					$_POST = self::arr_htmlspecialchars(self::arr_removeNonUtf8($_POST));
					$_GET = self::arr_htmlspecialchars(self::arr_removeNonUtf8($_GET));
					$_SERVER = self::arr_htmlspecialchars(self::arr_removeNonUtf8($_SERVER));
					$_REQUEST = self::arr_htmlspecialchars(self::arr_removeNonUtf8($_REQUEST));
					$_FILES = self::arr_htmlspecialchars(self::arr_removeNonUtf8($_FILES));

					// Cookies
					if(! class_exists('cookie'))
						$_COOKIE = self::arr_htmlspecialchars(self::arr_removeNonUtf8($_COOKIE));
					else if(cookie::getIsAllowed())
						$_COOKIE = self::arr_htmlspecialchars(self::arr_removeNonUtf8($_COOKIE));
					else {
						// Anyway check Master-Cookie
						if(! isset($_COOKIE[cookie::getMasterCookieName()]))
							$_COOKIE[cookie::getMasterCookieName()] = '';

						$_COOKIE[cookie::getMasterCookieName()] = self::htmlspecialchars(self::removeNonUtf8($_COOKIE[cookie::getMasterCookieName()]));
					}
				}
			}

			// Done. set initials to true
			self::setInit(true);
		}
	}
	
	/**
	 * Show if class is initialed
	 *
	 * @return boolean - show if class is initialed | true = yes | false = no
	 */
	public static function isInit() {
		return self::$init;
	}

	/**
	 * Set if class is initialed
	 *
	 * @param boolean $init - set if class is initialed | true = yes | false = no
	 */
	private static function setInit($init) {
		self::$init = $init;
	}

	/**
	 * Shows if pre-check should use HTML-entities or HTML-SpecialCharacters
	 *
	 * @return boolean - use entities instead of special characters? true = yes | false = no
	 */
	public static function isUseEntities() {
		return self::$useEntities;
	}

	/**
	 * Shows if pre-check is enabled
	 *
	 * @return boolean - check user input
	 */
	public static function isCheckUserInput() {
		return self::$checkUserInput;
	}

	/**
	 * Like http://php.net/htmlentities (htmlentities) but with different default parameters
	 *
	 * @param string $string - The string to convert
	 * @param int $quote - Quotes, see the functions documentation itself ( http://php.net/htmlentities ) - Default: ENT_QUOTES
	 * @param string $charset - Character-Set-Encoding - Default: UTF-8
	 * @param bool $double_encode - Convert full string or ignore already converted entities - Default: true (convert full)
	 * @return string - The converted string
	 */
	public static function htmlentities($string, $quote = ENT_QUOTES, $charset = 'UTF-8', $double_encode = true) {
		return htmlentities($string, $quote, $charset, $double_encode);
	}

	/**
	 * Like self::htmlentities but also work with arrays
	 *
	 * @param string|array $string - The array/string to convert
	 * @param int $quote - Quotes, see the functions documentation itself ( http://php.net/htmlentities ) - Default: ENT_QUOTES
	 * @param string $charset - Character-Set-Encoding - Default: UTF-8
	 * @param bool $double_encode - Convert full string or ignore already converted entities - Default: true (convert full)
	 * @return array|string - The converted string/array
	 */
	public static function arr_htmlentities($string, $quote = ENT_QUOTES, $charset = 'UTF-8', $double_encode = true) {
		if(is_array($string)) {
			$tmp = array();
			foreach($string as $key => $value) {
				$tmp[$key] = self::arr_htmlentities($value, $quote, $charset, $double_encode);
			}
			return $tmp;
		}

		return self::htmlentities($string, $quote, $charset, $double_encode);
	}

	/**
	 * Like http://php.net/htmlspecialchars (htmlspecialchars) but with different default parameters
	 *
	 * @param string $string - The string to convert
	 * @param int $flags - Quotes, see the functions documentation itself ( http://php.net/htmlspecialchars )- Default: ENT_QUOTES
	 * @param string $encoding - Character-Set-Encoding - Default: UTF-8
	 * @param bool $double_quote - Convert full string or ignore already converted entities - Default: true (convert full)
	 * @return string - The converted string
	 */
	public static function htmlspecialchars($string, $flags = ENT_QUOTES, $encoding = 'UTF-8', $double_quote = true){
		return htmlspecialchars($string, $flags, $encoding, $double_quote);
	}

	/**
	 * Like self::htmlspecialchars but also work with arrays
	 *
	 * @param string|array $string - The array/string to convert
	 * @param int $flags - Quotes, see the functions documentation itself ( http://php.net/htmlspecialchars )- Default: ENT_QUOTES
	 * @param string $encoding - Character-Set-Encoding - Default: UTF-8
	 * @param bool $double_quote - Convert full string or ignore already converted entities - Default: true (convert full)
	 * @return array|string - The converted string/array
	 */
	public static function arr_htmlspecialchars($string, $flags = ENT_QUOTES, $encoding = 'UTF-8', $double_quote = true) {
		if(is_array($string)) {
			$tmp = array();
			foreach($string as $key => $value) {
				$tmp[$key] = self::arr_htmlspecialchars($value, $flags, $encoding, $double_quote);
			}
			return $tmp;
		}

		return self::htmlspecialchars($string, $flags, $encoding, $double_quote);
	}

	/**
	 * Like http://php.net/html_entity_decode (html_entity_decode) but with different default parameters
	 *
	 * @param string $string - The string to convert
	 * @param int $quote - Quotes, see the functions documentation itself ( http://php.net/html_entity_decode ) - Default: ENT_QUOTES
	 * @param string $charset - Character-Set-Encoding - Default: UTF-8
	 * @return string - The converted string
	 */
	public static function html_entity_decode($string, $quote = ENT_QUOTES, $charset = 'UTF-8') {
		return html_entity_decode($string, $quote, $charset);
	}

	/**
	 * Like self::html_entity_decode but also work with arrays
	 *
	 * @param array|mixed $string - string/array to convert
	 * @param int $quote - Quotes, see the functions documentation itself ( http://php.net/html_entity_decode ) - Default: ENT_QUOTES
	 * @param string $charset - Character-Set-Encoding - Default: UTF-8
	 * @return array|mixed - The converted string/array
	 */
	public static function arr_html_entity_decode($string, $quote = ENT_QUOTES, $charset = 'UTF-8') {
		if(is_array($string)) {
			$tmp = array();
			foreach($string as $key => $value) {
				$tmp[$key] = self::arr_html_entity_decode($value, $quote, $charset);
			}
			return $tmp;
		}

		if(is_string($string))
			return self::html_entity_decode($string, $quote, $charset);
		else
			return $string;
	}

	/**
	 * Like http://php.net/lcfirst (lcfirst) but compatible with MultiByte Characters
	 *
	 * @param string $string - String to convert, see also: http://php.net/lcfirst
	 * @return string - String with first char lower
	 */
	public static function lcfirst($string) {
		return mb_strtolower(mb_substr($string, 0, 1)) . mb_substr($string, 1);
	}

	/**
	 * Like http://php.net/ucfirst (lcfirst) but compatible with MultiByte Characters
	 *
	 * @param string $string - String to convert, see also: http://php.net/ucfirst
	 * @return string - String with first char upper
	 */
	public static function ucfirst($string) {
		return mb_strtoupper(mb_substr($string, 0, 1)) . mb_substr($string, 1);
	}

	/**
	 *
	 *
	 * @param array|string $string - encode array/string to url
	 * @return array|string - encoded array/string
	 */
	public static function arr_urlencode($string) {
		if(is_array($string)) {
			$tmp = array();
			foreach($string as $key => $value) {
				$tmp[$key] = self::arr_urlencode($value);
			}
			return $tmp;
		}

		return urlencode($string);
	}

	/**
	 * Like http://php.net/rawurldecode (rawurldecode) but works also on arrays
	 *
	 * @param array|string $string - encode array/string to url
	 * @return array|string - encoded array/string
	 */
	public static function arr_rawurldecode($string) {
		if(is_array($string)) {
			$tmp = array();
			foreach($string as $key => $value) {
				$tmp[$key] = self::arr_rawurldecode($value);
			}
			return $tmp;
		}

		return rawurldecode($string);
	}

	/**
	 * Encode an string to RFC - Like this: http://php.net/rawurlencode
	 * ----
	 * Improvement: Thanks to bolvaritamas@vipmail.hu on PHP.NET for FULL UTF-8 convert!
	 *
	 * @param array|string $string - the string/array which should converted
	 * @return array|string - the converted string/array
	 */
	public static function arr_rawurlencode($string) {
		if(is_array($string)) {
			$tmp = array();
			foreach($string as $key => $value) {
				$tmp[$key] = self::arr_rawurlencode($value);
			}
			return $tmp;
		}

		// Function itself
		$result = "";
		$length = mb_strlen($string);

		for($i = 0; $i < $length; $i++)
			$result .= '%' . wordwrap(bin2hex(mb_substr($string, $i, 1)), 2, '%', true);

		return $result;
		// OLD return rawurlencode($string);
	}

	/**
	 * Like http://php.net/urldecode
	 *
	 * @param string - $str unicode and ulrencoded string, see also: http://php.net/urldecode
	 * @return string - decoded string
	 */
	public static function urldecode($string) {
		$string = preg_replace('/%u([0-9a-f]{3,4})/i', '&#x\\1;', urldecode($string));
		return self::html_entity_decode($string);
	}

	/**
	 * Like self::urldecode but also work with arrays
	 *
	 * @param array|mixed $string -  string/array unicode and ulrencoded string, see also: http://php.net/urldecode
	 * @return array|string - decoded array/string
	 */
	public static function arr_urldecode($string) {
		if(is_array($string)) {
			$tmp = array();
			foreach($string as $key => $value) {
				$tmp[$key] = self::arr_urldecode($value);
			}
			return $tmp;
		}

		return self::urldecode($string);
	}

	/**
	 * Detect encoding and convert it to UTF-8 and remove not allowed Encoding
	 *
	 * @param $string - Dirty, may not UTF-8 String
	 * @return bool|mixed|string - Clean UTF-8 String or false on error
	 * @throws Exception - UTF-7 Warn
	 */
	private static function removeNonUtf8($string) {
		if(mb_detect_encoding($string) != 'UTF-8')
			$string = mb_convert_encoding($string, 'UTF-8', mb_detect_encoding($string)); // Convert non UTF-8 String to UTF-8

		// Exit on UTF7
		if(mb_detect_encoding($string) == 'UTF-7')
			throw new Exception('UTF-7 is not allowed!');

		// Check if string is ascii or utf8 (utf-8 is ascii compatible, that is why this should be also checked)
		if(mb_detect_encoding($string) != 'UTF-8' && mb_detect_encoding($string) != 'ASCII')
			return false;
		$string = preg_replace('/[\xF0-\xF7].../s', '', $string); // Remove UTF16 chars

		return $string;
	}

	/**
	 * Same as self::removeNonUtf8 but it work also with arrays
	 *
	 * @param string|array $string - dirty array (may not utf8 encoded)
	 * @return array|mixed|string - clean array utf8
	 * @throws Exception - UTF-7 Warn
	 */
	private static function arr_removeNonUtf8($string) {
		if(is_array($string)) {
			$tmp = array();
			foreach($string as $key => $value) {
				$tmp[$key] = self::arr_removeNonUtf8($value);
			}
			return $tmp;
		}

		return self::removeNonUtf8($string);
	}

	/**
	 * Same as http://php.net/basename (basename) but work also with MultiBytes File/Directory-Names
	 * /!\ Usual not needed to use! There are no MultiBytes-File/Directory-Names yet, but may needed for some of you if your server has them Like Chine/Russian etc /!\
	 *
	 * @param string $path - Path to convert
	 * @param string|null $suffix - Remove this ending if exists
	 * @return string -  Filename without path (and may without suffix)
	 */
	public static function mb_basename($path, $suffix = null) {
		if(mb_stripos($path, DIRECTORY_SEPARATOR) !== false)
			$basename = mb_substr($path, mb_strripos($path, DIRECTORY_SEPARATOR));
		else
			$basename = $path;

		if($suffix && mb_stripos($basename, $suffix)) {
			$suffix_pos = mb_strlen($suffix) * -1;
			$base_end = mb_substr($basename, $suffix_pos);

			if($base_end == $suffix)
				$basename = mb_substr($basename, 0, $suffix_pos);
		}

		return $basename;
	}

	/**
	 * Checks if MultiBytes (mb) functions exists - They are needed for this Class!
	 *
	 * @throws Exception - Warning MB-Functions not found
	 */
	private static function checkMultiByteFunctions() {
		if(! function_exists('mb_detect_encoding') || ! function_exists('mb_convert_encoding'))
			throw new Exception('[Security]: Can\'t find mb_*_encoding functions, make sure that you have them in your PHP-Install');
		if(! function_exists('mb_substr') || ! function_exists('mb_strlen') || ! function_exists('mb_strripos') || ! function_exists('mb_stripos'))
			throw new Exception('[Security]: Can\'t find mb_str* functions, make sure that you have them in your PHP-Install');
	}
}
