<?php
/**
 * Author: Peter Dragicevic [peter-91@hotmail.de]
 * Authors-Website: http://petschko.eona.in/
 * Date: 24.11.2015 (RAW FILE)
 * Time: 14:47 (RAW FILE)
 * Update: 26.01.2016 (RAW FILE)
 * Version: 1.0.3 (RAW FILE)
 *
 * Notes: Contains Config stuff
 */

/**
 * Class config
 *
 * Single-Instance-Class
 */
class config_old {
	// Mysql settings
	const db_type = 'mysql';								// Type of the Database-Server (MySQL, SQLite etc)
	const db_host = '127.0.0.1';							// Hostname/IP of the Database-Server
	const db_port = 3306;									// Port of the Database-Server
	const db_user = 'root';									// Database User
	const db_password = 'root';								// Password of the Database User
	const db_website_db = 'website';						// Name of the Database
	const db_table_pref = '';								// Prefix of the tables and don't forget the _!! (if there is no prefix, let this empty)
	const db_charset = 'utf8';								// Database Charset

	// Cookie-Settings
	const cookie_police_set = false;						// Set cookie law, false means cookies will only set if the user accept it, after clicking on 'allow set cookies', true set normal cookies without asking. in Europe better set this to false
	const cookie_police_contry_mode_whitelist = true;		// true = Never ask for cookies in the selected countries | false = Only ask on the selected countries for cookies

	// Locale settings
	const default_lang = 'en';								// Default language
	public static $enabled_langs = array('de', 'en');		// Enabled languages (names are like the Language php-files (de.php => de, en.php => en and so on)

	// Misc settings
	const charset = 'UTF-8';								// Default Charset (UTF-8 recommend)
	const title = 'PageTitle';								// Will NOT used if the class 'lang' exists
}

