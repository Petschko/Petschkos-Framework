<?php
/**
 * Author: Peter Dragicevic [peter-91@hotmail.de]
 * Authors-Website: http://petschko.eona.in/
 * Date: 23.09.2015
 * Time: 09:54
 * Update: 25.01.2016
 * Version: 1.0.2
 * 
 * Licence: http://creativecommons.org/licenses/by-sa/4.0/
 */

// Check if constance is defined - if not define
if(! defined('DS'))
	define('DS', DIRECTORY_SEPARATOR);

/**
 * Class file
 */
class file_old {
	private static $default_perm = '0755';
	private $filename;
	private $name;
	private $path;
	private $filetype;
	private $dir;
	private $fullpath;

	/**
	 * Creates a new file object
	 *
	 * @param string $filepath - Path to the file
	 * @param bool $new - create a new file? true creates a new | false do not create a new
	 * @param bool $overwrite - overwrite existing file? true overwrite existing files | false do not overwrite existing files (only affect on create new)
	 * @param bool $new_dir - create a file or a directory? true creates a new directory | false creates a new file (only affect on create new)
	 * @throws Exception - File/directory not found
	 */
	public function __construct($filepath, $new = false, $overwrite = false, $new_dir = false) {
		if($new)
			$this->create($filepath, $overwrite, $new_dir);
		else
			$this->update_fileinfo($filepath);
	}

	/**
	 * Clears Memory
	 */
	public function __destruct() {
		unset($this->filename);
		unset($this->name);
		unset($this->path);
		unset($this->filetype);
		unset($this->dir);
		unset($this->fullpath);
	}

	/**
	 * Get the Path from a Filepath (but not get the last end of it) E.g /var/www/myfile.php will return /var/www/
	 *
	 * @param string $path - The Filepath + file
	 * @return string - The Path to the file (without the file at the end) if there is not a DIRECTORY SEPARATOR in the string return DIRECTORY SEPARATOR
	 */
	public static function getPathFromString($path) {
		$last_slash = strrpos($path, DS);

		if($last_slash !== false)
			return substr($path, 0, $last_slash);
		return DS;
	}

	/**
	 * Ensure, that the last character is a DIRECTORY SEPARATOR
	 *
	 * @param string $path - Path to check
	 * @return string - Path with ensured DIRECTORY SEPARATOR at the end
	 */
	private static function check_dir_path($path) {
		$lastchar = substr($path, -1);
		if($lastchar != DS)
			$path .= DS;

		return $path;
	}

	/**
	 * Creates a new file or directory
	 *
	 * @param string $path - The file path
	 * @param bool $overwrite - Overwrite the file if exists? true overwrite | false don't overwrite (Only affected on create a file)
	 * @param bool $new_dir - Create a new directory? true creates a new dir | false creates a new file
	 * @throws Exception - File/Directory not found
	 */
	public function create($path, $overwrite = false, $new_dir = false) {
		if($new_dir)
			if(! file_exists($path))
				$created = mkdir($path, self::getDefaultPerm(), true);
			else
				$created = true;
		else {
			$created = false;
			if(! file_exists($path) || $overwrite) {
				if(! file_exists(self::getPathFromString($path)))
					new self(self::getPathFromString($path), true, false, true); // Creates missing directories if there are some
				// Create a new empty file
				fclose(fopen($path, 'wb'));
			}
			else
				$created = true;

			if(file_exists($path))
				$created = true;
		}

		// Update file info
		if($created)
			$this->update_fileinfo($path);
		else
			unset($this);
	}

	/**
	 * Rename a file or directory
	 *
	 * @param string $newname - the new name
	 * @return bool - true on success else false
	 * @throws Exception - File/Directory not found
	 */
	public function rename($newname) {
		// "Move" File - Better say rename
		if(rename($this->getFullpath(), $this->getPath() . $newname)) {

			// Update fileinfo
			$this->update_fileinfo($this->getPath() . $newname);

			return true;
		}

		return false;
	}

	/**
	 * Move and may rename a file or directory
	 *
	 * @param string $newpath - The new destination of the file/directory
	 * @param string|bool $newname - The new name | false doesn't change the name
	 * @param bool $overwrite - Overwrites a file/directory if it exists at the destination | false do not overwrite | true overwrite
	 * @return bool - true on success else false
	 * @throws Exception - File/Directory not found
	 */
	public function move($newpath, $newname = false, $overwrite = false) {
		$newpath = self::check_dir_path($newpath);
		$path = $newpath . (($newname) ? $newname : $this->getFilename());

		if(! file_exists($path) || $overwrite) {
			// Delete existing dir if overwrite is allowed
			if($overwrite && file_exists($path) && is_dir($path) && $this->isDir()) {
				$deleteDir = new self($path);
				$deleteDir->delete();
			}

			// Move the file/directory
			$move = rename($this->getFullpath(), $path);

			if($move) {
				// Update File info
				$this->update_fileinfo($path);

				return true;
			}
		}
		return false;
	}

	/**
	 * Copy a file and may rename the new one and may create a new instance
	 *
	 * @param string $newpath - The destination of the copy of the file/directory
	 * @param string|bool $newname - The new name | false doesn't change the name
	 * @param bool $overwrite - Overwrites a file/directory if it exists at the destination | false do not overwrite | true overwrite
	 * @param bool $new_ressource - Create a new instance of this class for the copy of the file/directory? true does | false not
	 * @return bool|file - true on success else false and "file" on succes if new_ressource is true
	 */
	public function copy($newpath, $newname = false, $overwrite = false, $new_ressource = false) {
		$newpath = self::check_dir_path($newpath);
		$path = $newpath . (($newname) ? $newname : $this->getFilename());

		if(! file_exists($path) || $overwrite) {
			// Delete existing dir if overwrite is allowed
			if($overwrite && file_exists($path) && is_dir($path) && $this->isDir()) {
				$deleteDir = new self($path);
				$deleteDir->delete();
			}

			// Copy the file/directory
			if(copy($this->getFullpath(), $path)) {
				if($new_ressource)
					return new self($path);

				return true;
			}
		}
		return false;
	}

	/**
	 * Deletes the file/directory and remove this instance
	 */
	public function delete() {
		if($this->isDir()) {
			// Delete files and subfolder within the selected folder
			$this->clear();

			// Delete Folder
			rmdir($this->getFullpath());
			clearstatcache();
		} else {
			unlink($this->getFullpath());
			clearstatcache();
		}
		unset($this);
	}

	/**
	 * todo doku
	 *
	 * @param int $limit
	 * @param int $start
	 * @param bool $subdirs
	 * @return array|bool
	 */
	public function getContent($limit = 1000, $start = 0, $subdirs = false) {
		if($this->isDir()) {
			if($handle = opendir($this->getFullpath())) {
				$array = array();
				$i = 0;
				$ignore = 0;
				while(($file = readdir($handle)) !== false) {
					if($file != '.' && $file != '..') {
						$tmp_class = new self($this->getFullPath() . $file);
						if($ignore >= $start) {
							// Add file/dir to return array
							if(! $tmp_class->isDir() || $subdirs) {
								$array[$i] = $tmp_class;
								$i++;
							}

							// Stop if limit is reached
							if($i >= $limit && $limit > 0) {
								if(is_resource($handle))
									closedir($handle);
								clearstatcache();

								return $array;
							}
						}
						// Increase ignoreCounter and increase it on dirs if enabled
						if(! $tmp_class->isDir() || $subdirs)
							$ignore++;

						// Clear Memory
						unset($tmp_class);
					}
					unset($file);
				}

				// Close handle and clear cache/memory
				unset($ignore);
				if(is_resource($handle))
					closedir($handle);
				clearstatcache();

				return $array;
			}
		} else {
			// todo (show file content?)
		}

		return false;
	}

	/**
	 * Get the size of a file or directory
	 * ------------------------------------------------------------------------
	 * IMPORTANT: Because PHP's integer type is signed and many platforms use 32bit integers, some filesystem functions
	 * may return unexpected results for files which are larger than 2GB.
	 * See: http://php.net/manual/en/function.filesize.php
	 * ------------------------------------------------------------------------
	 *
	 * @return bool|int - The size of the file/directory (Bytes)
	 */
	public function getSize() {
		if($this->isDir()) {
			$bytes = 0;

			if($handle = opendir($this->getFullpath())) {
				// Count files
				while(($file = readdir($handle)) !== false) {
					if($file != '.' && $file != '..') {
						$tmp_class = new self($this->getFullPath() . $file);

						$bytes += $tmp_class->getSize();

						// Clear Memory
						unset($tmp_class);
					}
					unset($file);
				}
			}

			// Close handle and clear cache
			if(is_resource($handle))
				closedir($handle);
			clearstatcache();

			return $bytes;
		} else
			return filesize($this->getFullpath());
	}

	/**
	 * Get the number of files in this directory
	 *
	 * @param bool $excludeSubDirs - Do not Count files in subdirectories? true doesn't count files in subdirs | false count files in subdirs
	 * @param bool $countDirs - Count dirs in the direcorty too? true counts dirs as the same as files | false ignore dirs on counting
	 * @return int number of files - if the instance is a file this return always 1
	 */
	public function countFiles($excludeSubDirs = true, $countDirs = false) {
		if($this->isDir()) {
			$files = 0;
			if($handle = opendir($this->getFullpath())) {
				// Count files
				while(($file = readdir($handle)) !== false) {
					if($file != '.' && $file != '..') {
						$tmp_class = new self($this->getFullPath() . $file);

						// Is this a dir?
						if($tmp_class->isDir()) {
							// Count subdirs?
							if($countDirs)
								$files++;

							// Check the content of the sub-dirs too?
							if($excludeSubDirs === false)
								$files += $tmp_class->countFiles(false, $countDirs);
						} else
							$files++;

						// Clear Memory
						unset($tmp_class);
					}
					unset($file);
				}
			}
			// Close handle and clear cache
			if(is_resource($handle))
				closedir($handle);
			clearstatcache();

			return $files;
		} else
			return 1; // A File return always 1
	}

	/**
	 * Delete everything in a file or a directory
	 */
	public function clear() {
		if($this->isDir()) {
			if($handle = opendir($this->getFullpath())) {
				// Delete files and subfolder within the selected folder
				while(($file = readdir($handle)) !== false) {
					if($file != '.' && $file != '..') {
						$filecl = new self($this->getFullpath() . $file);
						$filecl->delete();
					}
				}

				// Close handle and clear cache
				if(is_resource($handle))
					closedir($handle);
				clearstatcache();
			}
		} else {
			$handle = fopen($this->getFullpath(), 'wb');

			// Close handle and clear cache
			if(is_resource($handle))
				closedir($handle);
			clearstatcache();
		}
	}

	/**
	 * Shows the creation time of a file
	 *
	 * @return int - creation time
	 */
	public function getCTime() {
		return filectime($this->getFullpath());
	}

	/**
	 * Shows the last modification time of a file
	 *
	 * @return int modification time
	 */
	public function getMTime() {
		return filemtime($this->getFullpath());
	}

	/**
	 * Changes the permission of a file or directory
	 *
	 * @param string|bool $perm - Permissions as a string or false if restoring the files default permissions
	 * @return bool - true on success else false
	 */
	public function chmod($perm = false) {
		return chmod($this->getFullpath(), ((is_string($perm)) ? octdec($perm) : self::getDefaultPerm()));
	}

	/**
	 * Update the information about this file/directory in this instance
	 *
	 * @param string $filepath - path of the file/directory MUST exist!
	 * @throws Exception - File/Directory not found
	 */
	private function update_fileinfo($filepath) {
		if(! file_exists($filepath))
			throw new Exception(__CLASS__ . '->' . __FUNCTION__ . ': &quot;' . $filepath . '&quot; doesn\'t exists!');

		$last_slash = strrpos($filepath, DS);
		$this->setFullpath($filepath);
		if(is_dir($this->getFullpath())) {
			$this->setDir(true);
			$this->setFiletype('DIRECTORY');

			// Check if last char is an slash if yes recheck to the previous slash
			$lastchar = substr($this->getFullpath(), -1);
			if($lastchar == DS) {
				$filepath = substr($filepath, 0, -1);
				$last_slash = strrpos($filepath, DS);
			} else
				$this->setFullpath($this->getFullpath() . DS);
			unset($lastchar);

			// Get path and directory name
			if($last_slash !== false) {
				$this->setPath(substr($this->getFullpath(), 0, $last_slash + 1));
				$this->setFilename(substr($this->getFullpath(), $last_slash + 1));
			} else {
				$this->setPath($this->getFullpath());
				$this->setFilename($this->getFullpath());
			}

			// Check if filename not end with slash
			$lastchar = substr($this->getFilename(), -1);
			if($lastchar == DS)
				$this->setFilename(substr($this->getFilename(), 0, -1));
			$this->setName($this->getFilename());
		} else {
			$this->setDir(false);

			// Get Filename
			if($last_slash !== false) {
				$this->setPath(substr($filepath, 0, $last_slash + 1));
				$file = substr($this->getFullpath(), $last_slash + 1);
			} else {
				$this->setPath($this->getFullpath());
				$file = $this->getFullpath();
			}
			$this->setFilename($file);

			$last_dot = stripos($file, '.');
			if($last_dot !== false) {
				$this->setName(substr($file, 0, $last_dot));
				$this->setFiletype(strtolower(substr($file, $last_dot + 1)));
			} else {
				$this->setName($this->getFilename());
				$this->setFiletype('NONE');
			}
		}
	}

	/**
	 * Get the Full-Path of the file or directory
	 *
	 * @return string - the path to the file/directory including the name of the dir/file
	 */
	public function getFullpath() {
		return $this->fullpath;
	}

	/**
	 * Set the Full-Path of the file or directory
	 *
	 * @param string $fullpath - the path to the file/directory including the name of the dir/file
	 */
	private function setFullpath($fullpath) {
		$this->fullpath = $fullpath;
	}

	/**
	 * Get the name of the file plus extension eg "index.php" or a directory
	 *
	 * @return string - The File name
	 */
	public function getFilename() {
		return $this->filename;
	}

	/**
	 * Set the name of the file plus extension eg "index.php" or a directory
	 *
	 * @param string $filename - The File name
	 */
	private function setFilename($filename) {
		$this->filename = $filename;
	}

	/**
	 * Get the name of the file without extension eg "index" instead of "index.php" or a directory
	 *
	 * @return string - The name
	 */
	public function getName() {
		return $this->name;
	}

	/**
	 * Set the name of the file without extension eg "index" instead of "index.php" or a directory
	 *
	 * @param string $name - The name
	 */
	private function setName($name) {
		$this->name = $name;
	}

	/**
	 * Get the Path to the file but without the filename itself or the path to the directory without the dir itself
	 *
	 * @return string - The Path to the dir/file
	 */
	public function getPath() {
		return $this->path;
	}

	/**
	 * Set the Path to the file but without the filename itself or the path to the directory without the dir itself
	 *
	 * @param string $path - The Path to the dir/file
	 */
	private function setPath($path) {
		$this->path = $path;
	}

	/**
	 * Get the File type of this instance
	 *
	 * @return string - file type of the file or "NONE" or "DIRECTORY"
	 */
	public function getFiletype() {
		return $this->filetype;
	}

	/**
	 * Set the File type of this instance
	 *
	 * @param string $filetype - file type
	 */
	private function setFiletype($filetype) {
		$this->filetype = $filetype;
	}

	/**
	 * @return bool - true if this instance is a directory else false
	 */
	public function isDir() {
		return $this->dir;
	}

	/**
	 * @param bool $dir - is this a directory? true is a directory | false is not a directory
	 */
	private function setDir($dir) {
		$this->dir = $dir;
	}

	/**
	 * Get the default permissions
	 *
	 * @return number - Default Permissions for chmod and functions that need permissions
	 */
	public static function getDefaultPerm() {
		return octdec(self::$default_perm);
	}

	/**
	 * Set the default permissions
	 *
	 * @param string $default_perm - Default Permissions for chmod and functions that need permissions
	 */
	public static function setDefaultPerm($default_perm) {
		self::$default_perm = $default_perm;
	}
}
