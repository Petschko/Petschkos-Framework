<?php
/**
 * Author: Peter Dragicevic [peter-91@hotmail.de]
 * Authors-Website: http://petschko.eona.in/
 * Licence: http://creativecommons.org/licenses/by-sa/4.0/
 * Date: 20.07.2015
 * Time: 09:46
 * Update: 19.02.2016
 * Version: 1.0.3 (Changed static Charset on htmlspecialchars to config::charset)
 * 
 * Notes: Switches between different Languages
 */

// Variable need to storage the different languages
if(! isset($lang))
	$lang = array();

/**
 * Class lang
 *
 * Single-Instance-Class
 */
class lang_old {
	private $instance;
	private $lang;

	/**
	 * Crates this instance
	 *
	 * @param string $user_lang - selected language
	 */
	public function __construct($user_lang) {
		if(! $this->getInstance()) {
			$cookie = $this->get_lang_cookie($user_lang);
			if($user_lang == '' && ! $cookie)
				$this->setLang(config::default_lang);
			else if($cookie)
				$this->setLang($cookie);
			else {
				$this->setLang($user_lang);
				$this->set_lang_cookie($user_lang);
			}
			$this->setInstance($this);
		}
	}
	
	/**
	 * Save include a PHP-file
	 *
	 * @param string $filepath - Path to the file
	 * @param string $filename - Filename
	 * @return mixed - Include-File
	 * @throws Exception - File not found 404
	 */
	private static function save_include($filepath, $filename) {
		$clean_filename = basename($filename, '.php');
		$clean_filename = str_replace('/', '', $clean_filename); // For fallback
		$clean_filename = str_replace(DS, '', $clean_filename);

		$filepath = str_replace(':', '', $filepath); // Remove protocol

		if(file_exists($filepath . $clean_filename . '.php'))
			return require_once($filepath . $clean_filename . '.php');
		else
			throw new Exception(
				self::display('exception_save_include_404',
					array(
						'file' => $filepath . $clean_filename . '.php',
						'class' => (string) __CLASS__,
						'function' => (string) __FUNCTION__
					)
				));
	}

	/**
	 * Display the var in the correct language
	 *
	 * @param string $locale_name - name of the var
	 * @param array $array - params to replace
	 * @return string - locale string with replaced vars
	 */
	public static function display($locale_name, $array = array()) {
		global $lang;

		// Check if the var exists
		if(! isset($lang[$locale_name])) {
			if(class_exists('utf8'))
				return utf8::htmlspecialchars("[LANG-VAR missing: \"{$locale_name}\"]");
			else
				return htmlspecialchars("[LANG-VAR missing: \"{$locale_name}\"]", ENT_QUOTES, config::charset, true);
		}
		$string = $lang[$locale_name];

		// Replace values
		if(mb_substr_count($string, '%') > 0) {
			foreach($array as $key => $value) {
				$string = str_replace('%' . $key . '%', $value, $string);
			}
		}

		return $string;
	}

	/**
	 * Returns a static language html file
	 *
	 * @param string $loc - destination file
	 * @param string $from - path to file
	 * @return mixed - Return files
	 */
	public function require_locale_file($loc, $from = null) {
		if(mb_stripos($loc, '_', 0))
			$loc = mb_substr(mb_strrchr($loc, '_'), 1);

		if($from === null)
			$from = HTMLDIR . DS . 'content' . DS;

		// Add DS to end ot the path if not exists
		if(mb_substr($from, -1) != DS)
			$from .= DS;

		if(file_exists($from . basename($loc . '.php'))) {
			// Exists locale file?
			if(file_exists($from . basename($loc . '.' . $this->get_locale() . '.php')))
				return self::save_include($from, $loc . '.' . $this->get_locale());

			// Return default file
			return self::save_include($from, $loc);
		}

		// 404 File not found
		return require_once(HTMLDIR . DS . '404.html');
	}

	/**
	 * Check if the language exists, if not return default language
	 *
	 * @return string - shows current user language on error show default lang
	 */
	public function get_locale() {
		foreach(config::$enabled_langs as $value) {
			if($value == $this->getLang())
				return $this->getLang();
		}

		// If not found in enabled lang show default
		return config::default_lang;
	}

	/**
	 * Returns this instance
	 *
	 * @return mixed - get class instance
	 */
	public function getInstance() {
		return $this->instance;
	}

	/**
	 * Set this instance
	 *
	 * @param mixed $instance - set class instance
	 */
	private function setInstance($instance) {
		$this->instance = $instance;
	}

	/**
	 * Returns the current set language
	 *
	 * @return string - get the lang of this class
	 */
	public function getLang() {
		return $this->lang;
	}

	/**
	 * Set the current language
	 *
	 * @param string $lang - set the lang of this class
	 */
	private function setLang($lang) {
		$this->lang = $lang;
	}

	/**
	 * Try to read a language cookie and return it
	 *
	 * @param string $get_lang - language
	 * @return bool|string - false on no-cookie, cookie value on cookie
	 */
	private function get_lang_cookie($get_lang) {
		if(class_exists('cookie')) {
			if(cookie::getcookie('locale') === false)
				return false;
			
			if($get_lang != '' && $get_lang != cookie::getcookie('locale', $get_lang)) {
				$this->set_lang_cookie($get_lang);
				return false;
			}
			
			return cookie::getcookie('locale', $get_lang);
		} else {
			if(! isset($_COOKIE['locale']))
				$_COOKIE['locale'] = null;

			if($get_lang != '' && $get_lang != $_COOKIE['locale']) {
				$this->set_lang_cookie($get_lang);
				return false;
			}
			
			return $_COOKIE['locale'];
		}
	}

	/**
	 * Set an user language Cookie
	 *
	 * @param $user_lang - language
	 */
	private function set_lang_cookie($user_lang = config::default_lang) {
		// Locale Cookies expires after 3 months
		if(class_exists('cookie'))
			cookie::setCookie('locale', $user_lang, time() + 7776000);
		else
			setcookie('locale', $user_lang, time() + 7776000);
	}
}
