<?php
/**
 * Author: Peter Dragicevic [peter-91@hotmail.de]
 * Authors-Website: http://petschko.eona.in/
 * Date: 25.11.2015
 * Time: 16:03
 * Update: 19.02.2016
 * Version: 2.1.2 (Fixed Textarea-HTML Output-Bug)
 * 2.1.1 (Added minLength to Textarea and Input)
 * 2.1.0 (Added TEXTAREA constructor, Values & Output)
 * 2.0.1 (Added trim to value to remove spaces at begin/end)
 * 2.0.0 (Added auto-max/minLength and auto-dataType and html5 features)
 *
 * Notes: Easily create Forms (Generates HTML)
 */

/**
 * Class FormField
 */
class FormField_old {
	const TYPE_BOOL = 'bool';
	const TYPE_STRING = 'string';
	const TYPE_INT = 'int';
	const TYPE_DOUBLE = 'double';
	const TYPE_NUMBER = 'number';
	const TYPE_PHONE = 'phone';
	const TYPE_EMAIL = 'email';
	const TYPE_TIME = 'time';
	const TYPE_DATE = 'date';
	const TYPE_DATETIME = 'datetime';
	const TYPE_URL = 'url';
	const TYPE_COLOR = 'color';
	const TYPE_TEXT = 'text';
	const TYPE_ZIP = 'zip';

	private static $xhtml = false;
	private static $html5 = true;
	private $name;
	private $value;
	private $type;
	private $enabled;
	private $readOnly = false;
	private $cssIds;
	private $cssClasses;
	private $otherHTMLattr;
	private $checked = false;
	private $selectList = null;
	private $multipleSelect = false;
	private $size = null;
	private $isPostVar = true;
	private $required = true;
	private $minLen = 0;
	private $maxLen = 0;
	private $currentLen;
	private $dataType = self::TYPE_STRING;
	private $rows;
	private $cols;

	/**
	 * Creates a new instance of a form field
	 *
	 * @param string $name - name of the form field object
	 * @param string|array $value - current value of the object - it can be an array for select list - multiple
	 * @param string $type - type of the current object
	 * @param bool $isPost - is the form var saved to a post or get var
	 * @param array|null $cssId - css ID(s) of the object
	 * @param array|null $cssClasses - css Class(es) of the object
	 * @param bool $enabled - disable/enable this object (false - disabled | true - enabled)
	 * @param string|null $other - all other not listed HTML-Attr write it as an normal HTML-String
	 */
	private function __construct($name, $value = '', $type = 'text', $isPost = true, $cssId = null, $cssClasses = null, $enabled = true, $other = null) {
		$this->setName($name);
		$this->setValue($value);

		if(self::isHtml5())
			$this->setType($type);
		else
			$this->setType(self::removeHtml5Type($type));

		$this->setIsPostVar($isPost);
		$this->setCssIds($cssId);
		$this->setCssClasses($cssClasses);
		$this->setEnabled($enabled);
		$this->setOtherHTMLattr($other);

		// If is submit field is not required
		if(mb_strtolower($this->getType()) == 'submit')
			$this->setRequired(false);

		// Auto assign DataType
		$this->autoSetDataType($type);
	}

	/**
	 * Clears Memory
	 */
	public function __destruct() {
		unset($this->name);
		unset($this->value);
		unset($this->type);
		unset($this->isPostVar);
		unset($this->enabled);
		unset($this->readOnly);
		unset($this->cssIds);
		unset($this->cssClasses);
		unset($this->otherHTMLattr);
		unset($this->checked);
		unset($this->selectList);
		unset($this->multipleSelect);
		unset($this->size);
		unset($this->required);
		unset($this->minLen);
		unset($this->maxLen);
		unset($this->currentLen);
		unset($this->dataType);
		unset($this->rows);
		unset($this->cols);
	}

	/**
	 * Returns true if you use XHTML
	 *
	 * @return boolean - is this XHTML code
	 */
	public static function isXhtml() {
		return self::$xhtml;
	}

	/**
	 * Set the value of XHTML use
	 *
	 * @param boolean $xhtml - enable/disable XHTML (true = enable | false = disable)
	 */
	public static function setXhtml($xhtml) {
		self::$xhtml = $xhtml;
	}

	/**
	 * Returns true if HTML5 is enabled
	 *
	 * @return boolean - is HTML5 enabled (true = yes | false = no)
	 */
	public static function isHtml5() {
		return self::$html5;
	}

	/**
	 * Set HTML5 on/off
	 *
	 * @param boolean $html5 - enable/disable HTML5 (true = enable | false = disable)
	 */
	public static function setHtml5($html5) {
		self::$html5 = $html5;
	}

	/**
	 * Removes HTML5 types to input type text other non-HTML5 types will return normal
	 *
	 * @param string $type - Type to check
	 * @return string - New type (text) or the other non HTML5 Type
	 */
	private static function removeHtml5Type($type) {
		switch(mb_strtolower($type)) {
			case 'color':
			case 'date':
			case 'datetime':
			case 'datetime-local':
			case 'email':
			case 'month':
			case 'number':
			case 'range':
			case 'search':
			case 'tel':
			case 'time':
			case 'url':
			case 'week':
				$type = 'text';
		}

		return $type;
	}

	/**
	 * Like the constructor but only make select fields
	 *
	 * @param string $name - name of the form field object
	 * @param array $selectList - the list of the select options
	 * @param string|array|null $value - current value of the object - it can be an array for select list - multiple - null detect value itself
	 * @param bool $isPost - is the form var saved to a post or get var
	 * @param bool $multiSelect - is multiSelect on the select field is allowed
	 * @param array|null $cssId - css ID(s) of the object
	 * @param array|null $cssClasses - css Class(es) of the object
	 * @param bool $enabled - disable/enable this object (false - disabled | true - enabled)
	 * @param string|null $other - all other not listed HTML-Attr write it as an normal HTML-String
	 * @return FormField - new instance
	 * @throws Exception - bad value
	 */
	public static function createNewSelect($name, $selectList, $value = null, $isPost = true, $multiSelect = false, $cssId = null, $cssClasses = null, $enabled = true, $other = null) {
		if($value === null)
			$value = self::detectValue($name, $isPost);

		$obj = new self($name, $value, 'select', $isPost, $cssId, $cssClasses, $enabled, $other);
		$obj->setSelectList($selectList);
		$obj->setMultipleSelect($multiSelect);

		return $obj;
	}

	/**
	 * Like the constructor but only make radio buttons
	 *
	 * @param string $name - name of the form field object
	 * @param string|array $value - current value of the object - it can be an array for select list - multiple
	 * @param bool|null $checked - is the radio button selected - null detect it itself
	 * @param bool $isPost - is the form var saved to a post or get var
	 * @param array|null $cssId - css ID(s) of the object
	 * @param array|null $cssClasses - css Class(es) of the object
	 * @param bool $enabled - disable/enable this object (false - disabled | true - enabled)
	 * @param string|null $other - all other not listed HTML-Attr write it as an normal HTML-String
	 * @return FormField - new instance
	 */
	public static function createNewRadioButton($name, $value, $checked = null, $isPost = true, $cssId = null, $cssClasses = null, $enabled = true, $other = null) {
		$tmp_return = self::detectValue($name, $isPost);

		// Check if value is returned if none is given
		if($checked === null) {
			if($tmp_return == $value)
				$checked = true;
			else
				$checked = false;
		}

		$obj = new self($name, $value, 'radio', $isPost, $cssId, $cssClasses, $enabled, $other);
		$obj->setChecked($checked);

		return $obj;
	}

	/**
	 * Like the constructor but only make checkboxes
	 *
	 * @param string $name - name of the form field object
	 * @param string|array $value - current value of the object - it can be an array for select list - multiple
	 * @param bool|null $checked - is the radio button selected - null detect it itself
	 * @param bool $isPost - is the form var saved to a post or get var
	 * @param array|null $cssId - css ID(s) of the object
	 * @param array|null $cssClasses - css Class(es) of the object
	 * @param bool $enabled - disable/enable this object (false - disabled | true - enabled)
	 * @param string|null $other - all other not listed HTML-Attr write it as an normal HTML-String
	 * @return FormField - new instance
	 */
	public static function createNewCheckBox($name, $value, $checked = null, $isPost = true, $cssId = null, $cssClasses = null, $enabled = true, $other = null) {
		$tmp_return = self::detectValue($name, $isPost);

		// Check if value is returned if none is given
		if($checked === null) {
			if($tmp_return == $value)
				$checked = true;
			else
				$checked = false;
		}

		$obj = new self($name, $value, 'checkbox', $isPost, $cssId, $cssClasses, $enabled, $other);
		$obj->setChecked($checked);

		return $obj;
	}

	/**
	 * Like the constructor but only make TextAreas
	 *
	 * @param string $name - Name of the TextArea-Field
	 * @param null|int $cols - Cols of the TextArea
	 * @param null|int  $rows - Rows of the TextArea
	 * @param string|null $value - current value of the object - null detect value itself
	 * @param bool $isPost - is the form var saved to a post or get var
	 * @param array|null $cssId - css ID(s) of the object
	 * @param array|null $cssClasses - css Class(es) of the object
	 * @param bool $enabled - disable/enable this object (false - disabled | true - enabled)
	 * @param string|null $other - all other not listed HTML-Attr write it as an normal HTML-String
	 * @return FormField - new instance
	 */
	public static function createNewTextArea($name, $cols = null, $rows = null, $value = null, $isPost = true, $cssId = null, $cssClasses = null, $enabled = true, $other = null) {
		if($value === null)
			$value = self::detectValue($name, $isPost);

		$obj = new self($name, $value, 'textarea', $isPost, $cssId, $cssClasses, $enabled, $other);
		$obj->setRows($rows);
		$obj->setCols($cols);

		return $obj;
	}

	/**
	 * The new constructor - creates a new instance
	 *
	 * @param string $name - name of the form field object
	 * @param string $type - type of the current object
	 * @param string|null $value - current value of the object - null detect value itself
	 * @param bool $isPost - is the form var saved to a post or get var
	 * @param array|null $cssId - css ID(s) of the object
	 * @param array|null $cssClasses - css Class(es) of the object
	 * @param bool $enabled - disable/enable this object (false - disabled | true - enabled)
	 * @param string|null $other - all other not listed HTML-Attr write it as an normal HTML-String
	 * @return FormField - new instance
	 * @throws Exception - bad function
	 */
	public static function createNewField($name, $type = 'text', $value = null, $isPost = true, $cssId = null, $cssClasses = null, $enabled = true, $other = null) {
		if(in_array(mb_strtolower($type), array('radio', 'checkbox', 'select', 'textarea')))
			throw new Exception(__CLASS__ . '::' . __FUNCTION__ . ': Please use the special create functions for textarea, select, radio & checkbox!');

		if($value === null)
			$value = self::detectValue($name, $isPost);

		return new self($name, $value, $type, $isPost, $cssId, $cssClasses, $enabled, $other);
	}

	/**
	 * Auto detects Value for the specified field
	 *
	 * @param string $name - Fieldname
	 * @param bool $isPost - Is it a POST or GET Variable
	 * @return mixed - Value
	 */
	private static function detectValue($name, $isPost) {
		// PreCheck var and assign
		if($isPost) {
			if(! isset($_POST[$name]))
				$_POST[$name] = false;

			return $_POST[$name];
		} else {
			if(! isset($_GET[$name]))
				$_GET[$name] = false;

			return $_GET[$name];
		}
	}

	/**
	 * Returns the value of the Rows for a TextArea
	 *
	 * @return null|int - Rows of the TextArea or null if none is set
	 */
	private function getRows() {
		return $this->rows;
	}

	/**
	 * Set the Rows of the TextArea
	 *
	 * @param null|int $rows - Rows of the TextArea or null to unset
	 */
	private function setRows($rows) {
		$this->rows = $rows;
	}

	/**
	 * Returns the value of the Cols for a TextArea
	 *
	 * @return null|int - Cols of the TextArea or null if none is set
	 */
	private function getCols() {
		return $this->cols;
	}

	/**
	 * Set the Cols of the TextArea
	 *
	 * @param null|int $cols - Cols of the TextArea or null to unset
	 */
	private function setCols($cols) {
		$this->cols = $cols;
	}

	/**
	 * Returns the allowed DataType of the value
	 *
	 * @return string - Allowed DataType
	 */
	public function getDataType() {
		return $this->dataType;
	}

	/**
	 * Set the allowed DataType of the value
	 *
	 * @param string $dataType - Allowed DataType
	 */
	public function setDataType($dataType) {
		$this->dataType = $dataType;
	}



	/**
	 * Returns true if the object is checked else false
	 *
	 * @return boolean - is the object checked
	 */
	public function isChecked() {
		return $this->checked;
	}

	/**
	 * Set if the object is checked
	 *
	 * @param boolean $checked - is the object checked (true = checked | false = not checked)
	 */
	public function setChecked($checked) {
		$this->checked = $checked;
	}

	/**
	 * Returns true if the object is required
	 *
	 * @return boolean - is this field required
	 */
	public function isRequired() {
		return $this->required;
	}

	/**
	 * Set if the object is required
	 *
	 * @param boolean $required - is this field required (true = yes | false = no)
	 */
	public function setRequired($required) {
		$this->required = $required;
	}


	/**
	 * Returns true if the var is send via POST else false
	 *
	 * @return bool - is the form value saved to a post or get var
	 */
	public function isPostVar() {
		return $this->isPostVar;
	}

	/**
	 * Set is var send via POST
	 *
	 * @param bool $isPostVar - is the form var saved to a post or get var (true = yes | false = no)
	 */
	private function setIsPostVar($isPostVar) {
		$this->isPostVar = $isPostVar;
	}

	/**
	 * Returns the list of a select object
	 *
	 * @return null|array - the list of an select input field - null means no list
	 */
	public function getSelectList() {
		return $this->selectList;
	}

	/**
	 * Set the list of a select object
	 *
	 * @param null|array $selectList - the list of an selected input field - null means no list
	 * @throws Exception - wrong type
	 */
	public function setSelectList($selectList) {
		if($selectList === null || is_array($selectList))
			$this->selectList = $selectList;
		else
			throw new Exception(__CLASS__ . '->' . __FUNCTION__ . ': selectList has to be an array or null! ' . gettype($selectList) . ' given...');
	}

	/**
	 * Returns true if the user can select more than 1 option in this select object else false
	 *
	 * @return boolean - can user select multiple options
	 */
	public function isMultipleSelect() {
		return $this->multipleSelect;
	}

	/**
	 * Set if the user can select multiple options in this select object
	 *
	 * @param boolean $multipleSelect - can user select multiple options (true = yes | false = no)
	 */
	public function setMultipleSelect($multipleSelect) {
		$this->multipleSelect = $multipleSelect;
	}


	/**
	 * Returns the name of this object
	 *
	 * @return string - the name of this object
	 */
	public function getName() {
		return $this->name;
	}

	/**
	 * Set the name of this object
	 *
	 * @param string $name - the name of this object
	 */
	private function setName($name) {
		$this->name = $name;
	}

	/**
	 * Returns the current value of this object
	 *
	 * @return string|array - the current value of this object
	 */
	public function getValue() {
		return $this->value;
	}

	/**
	 * Set the current value of this object
	 *
	 * @param string|array $value - the current value of this object
	 */
	public function setValue($value) {
		$this->value = trim($value);
	}

	/**
	 * Returns the size of the object - null means no limit
	 *
	 * @return null|int - size of the object - null means no limit
	 */
	public function getSize() {
		return $this->size;
	}

	/**
	 * Set the size of the object - null means no limit
	 *
	 * @param null|int $size - size of the object - null means no limit
	 */
	public function setSize($size) {
		if(is_numeric($size) || $size === null)
			$this->size = $size;
	}

	/**
	 * Get the current type of this object
	 *
	 * @return string - the current type of this object
	 */
	public function getType() {
		return $this->type;
	}

	/**
	 * Set the current type of this object
	 *
	 * @param string $type - the current type of this object
	 */
	private function setType($type) {
		$this->type = mb_strtolower($type);
	}

	/**
	 * Returns true if the object is enabled else false
	 *
	 * @return boolean - is this object enabled
	 */
	public function isEnabled() {
		return $this->enabled;
	}

	/**
	 * Set if the object is enabled
	 *
	 * @param boolean $enabled - enable disable this object (true = enabled | false = disabled)
	 */
	public function setEnabled($enabled) {
		$this->enabled = $enabled;
	}

	/**
	 * Returns true if you can only read the field
	 *
	 * @return boolean - Can field only read? true = readOnly | false = write/read
	 */
	public function isReadOnly() {
		return $this->readOnly;
	}

	/**
	 * Set if field can only read
	 *
	 * @param boolean $readOnly - Can field only read? true = readOnly | false = write/read
	 */
	public function setReadOnly($readOnly) {
		$this->readOnly = $readOnly;
	}

	/**
	 * Returns the value of chars that this field must have at least
	 *
	 * @return int - min length of the field
	 */
	public function getMinLen() {
		return $this->minLen;
	}

	/**
	 * Set the value of chars that this field must have at least
	 *
	 * @param int $minLen - min length of the field.
	 */
	public function setMinLen($minLen) {
		$this->minLen = $minLen;
	}

	/**
	 * Returns the value of chars that this field can have max
	 *
	 * @return int - max length 0 means no limit
	 */
	public function getMaxLen() {
		return $this->maxLen;
	}

	/**
	 * Set the value of chars that this field can have max
	 *
	 * @param int $maxLen - max length 0 means no limit
	 */
	public function setMaxLen($maxLen) {
		$this->maxLen = $maxLen;
	}

	/**
	 * Returns the current length of the value and set it if not set before
	 *
	 * @return int - length of the value
	 */
	public function getCurrentLen() {
		if(! isset($this->currentLen))
			$this->setCurrentLen();

		return $this->currentLen;
	}

	/**
	 * Set the current length of the value
	 */
	private function setCurrentLen() {
		$this->currentLen = mb_strlen($this->getValue());
	}

	/**
	 * Returns the CSS-ID(s) or null
	 *
	 * @return array|null - CSS-ID(s) as array or null if there are none
	 */
	private function getCssIds() {
		return $this->cssIds;
	}

	/**
	 * Set the CSS-ID(s)
	 *
	 * @param array|null $cssIds - CSS-ID(s) as array or null if there are none
	 */
	private function setCssIds($cssIds) {
		$this->cssIds = $cssIds;
	}

	/**
	 * Returns CSS-ID(s) as HTML-string
	 *
	 * @return string - HTML-string
	 */
	private function cssIdsHTML() {
		if($this->getCssIds() === null)
			return '';

		$code = '';
		foreach($this->getCssIds() as $cssId) {
			$code .= ' ' . $cssId;
		}

		return ' id="' . trim($code) . '"';
	}

	/**
	 * Returns CSS-Class(es) or null
	 *
	 * @return array|null - CSS-Class(es) as array or null if there are none
	 */
	private function getCssClasses() {
		return $this->cssClasses;
	}

	/**
	 * Set CSS-Class(es)
	 *
	 * @param array|null $cssClasses - CSS-Class(es) as array or null if there are none
	 */
	private function setCssClasses($cssClasses) {
		$this->cssClasses = $cssClasses;
	}

	/**
	 * Returns CSS-Class(es) as HTML-string
	 *
	 * @return string - HTML-String
	 */
	private function cssClassesHTML() {
		if($this->getCssClasses() === null)
			return '';

		$code = '';
		foreach($this->getCssClasses() as $cssClass) {
			$code .= ' ' . $cssClass;
		}

		return ' class="' . trim($code) . '"';
	}

	/**
	 * Add a CSS-Class to the object
	 *
	 * @param string $cssClassName - the name of a css class, no "," needed!!!
	 */
	public function addCssClass($cssClassName) {
		$this->cssClasses[] = $cssClassName;
	}

	/**
	 * Remove a CSS-Class from the object
	 *
	 * @param string $cssClassName - the name of a css class
	 */
	public function removeCssClass($cssClassName) {
		// Create a new array and include all values to it except the remove css class
		$tmp_new = array();
		$i = 0;
		foreach($this->getCssClasses() as $cssClass) {
			if($cssClassName != $cssClass) {
				$tmp_new[$i] = $cssClass;
				$i++;
			}
		}

		$this->setCssClasses($tmp_new);
	}

	/**
	 * Add a CSS-ID to the object
	 *
	 * @param string $cssIdName - the name of a css ID, no "," needed!!!
	 */
	public function addCssId($cssIdName) {
		$this->cssIds[] = $cssIdName;
	}

	/**
	 * Remove a CSS-ID from the object
	 *
	 * @param string $cssIdName - the name of a css ID
	 */
	public function removeCssId($cssIdName) {
		// Create a new array and include all values to it except the remove css class
		$tmp_new = array();
		$i = 0;
		foreach($this->getCssIds() as $cssId) {
			if($cssIdName != $cssId) {
				$tmp_new[$i] = $cssId;
				$i++;
			}
		}

		$this->setCssIds($tmp_new);
	}

	/**
	 * Returns all other HTML-Stuff or null
	 *
	 * @return string|null - all other html attributes - null if there are none
	 */
	public function getOtherHTMLattr() {
		return $this->otherHTMLattr;
	}

	/**
	 * Set all other CSS stuff
	 *
	 * @param string|null $otherHTMLattr - all other html attributes - null if there are none
	 */
	public function setOtherHTMLattr($otherHTMLattr) {
		$this->otherHTMLattr = $otherHTMLattr;
	}

	/**
	 * Check if the value dataType is the same as required on this field and convert them to the correct type
	 *
	 * @return bool - true on success else false
	 */
	public function checkDataType() {
		$value = $this->getValue();

		// Go to the right dataType to check
		switch($this->getDataType()) {

			case self::TYPE_BOOL:
				// Convert value to bool
				if(is_string($value))
					$this->setValue((boolean) $value);
				else if(! is_bool($value))
					return false;
				break;

			case self::TYPE_INT:
				// Check if string contains only numbers
				if(is_string($value)) {
					if(! ctype_digit($value)) {

						// May its an negative value check it out
						if(! mb_substr($value, 0, 1) == '-') {
							if(! ctype_digit(mb_substr($value, 1)))
								return false;
						} else
							return false;
					}
				} else if(! is_int($value))
					return false;

				// Convert to int
				$this->setValue((int) $value);
				break;

			case self::TYPE_DOUBLE:
				// Check if string is numeric
				if(is_string($value)) {
					if(! is_numeric($value))
						return false;
				} else if(! (is_int($value) || is_float($value)))
					return false;

				// Convert to float
				$this->setValue((float) $value);
				break;

			case self::TYPE_NUMBER:
				if(is_string($value)) {
					if(! is_numeric($value))
						return false;
				} else
					return false;
				break;

			case self::TYPE_PHONE:
				if(! is_string($value))
					return false;

				// Verify that its a number (with special chars) of typical numbers
				if(! preg_match('/([^0-9-+ \/\(\)])$/', $value))
					return false;
				break;

			case self::TYPE_STRING:
				// Check if its a string
				if(! is_string($value))
					return false;

				//todo regex remove htmlEntities
				break;

			case self::TYPE_EMAIL:
				if(! is_string($value))
					return false;

				// Check E-Mail pattern
				$atPos = mb_strpos($value, '@');
				$lastPointPos = mb_strrpos($value, '.');

				if(! $atPos || ! $lastPointPos)
					return false;

				if(! ($atPos > 0 && $lastPointPos > ($atPos + 1) && mb_strlen($value) > ($lastPointPos + 1)))
					return false;
				break;

			case self::TYPE_COLOR:
				//todo
			case self::TYPE_URL:
				if(! is_string($value))
					return false;

				// Only allow specific Characters to URLs
				if(! preg_match('/([^0-9a-zA-Z+_ #~&@=,;:\|\-\?\.\/])$/', $value)) // todo test
					return false;

				// Correct URL
				//$this->setValue(); //todo

				break;
			case self::TYPE_TIME:
				//todo
			case self::TYPE_DATE:
				//todo
			case self::TYPE_DATETIME:
				//todo
			case self::TYPE_ZIP:
				//todo

			case self::TYPE_TEXT:
			default:
				if(! is_string($value))
					return false;

		}

		return true;
	}

	/**
	 * Autodetect dataType for every FieldType and assign it (can changed later)
	 * Set also auto lengths can changed later too :)
	 *
	 * @param string|null $type - Current Field-Type
	 */
	private function autoSetDataType($type = null) {
		// Is a Type set? If not use object field type
		if($type === null)
			$type = $this->getType();

		switch(mb_strtolower($type)) {
			case 'color':
				$this->setDataType(self::TYPE_COLOR);
				$this->setMinLen(3);
				$this->setMaxLen(7);
				break;

			case 'time':
				$this->setDataType(self::TYPE_TIME);
				$this->setMinLen(3);
				$this->setMaxLen(5);
				break;

			case 'date':
				$this->setDataType(self::TYPE_DATE);
				$this->setMinLen(6);
				$this->setMaxLen(10);
				break;

			case 'datetime':
			case 'datetime-local':
				$this->setDataType(self::TYPE_DATETIME);
				$this->setMaxLen(16);
				break;

			case 'email':
				$this->setDataType(self::TYPE_EMAIL);
				$this->setMinLen(6);
				$this->setMaxLen(256);
				break;

			case 'tel':
				$this->setDataType(self::TYPE_PHONE);
				$this->setMaxLen(30);
				break;

			case 'url':
				$this->setDataType(self::TYPE_URL);
				$this->setMinLen(11);
				break;

			case 'range':
			case 'number':
				$this->setDataType(self::TYPE_NUMBER);
				break;
		}
	}

	/**
	 * Output this object
	 *
	 * @return string - HTML-Code
	 */
	public function output() {
		switch($this->getType()) {
			case 'select':
				return $this->selectHTML();
			case 'radio':
			case 'checkbox':
				return $this->radioButtonHTML();
			case 'textarea':
				return $this->textAreaHTML();
			default:
				// Returns input by default declare extra fields as case
				return $this->inputHTML();
		}
	}

	/**
	 * Returns a SELECT object as HTML-Code
	 *
	 * @return string - SELECT-HTML-Code
	 */
	private function selectHTML() {
		if($this->getSelectList() === null)
			return '[SELECT - Info at line ' . __LINE__ . ' in file ' . __FILE__ . ']: Please use (this)->setSelectList(array()); to set the list... It\'s empty yet!';

		// Create SELECT field
		$code = '<select name="' . $this->getName() . (($this->isMultipleSelect()) ? '[]' : '') . '"' . $this->cssIdsHTML() . $this->cssClassesHTML();

		// Add size if its not the default size
		if($this->getSize() !== null && $this->getSize() != 1)
			$code .= ' size="' . $this->getSize() . '"';

		// Include other HTML attr
		if($this->getOtherHTMLattr() !== null)
			$code .= ' ' . $this->getOtherHTMLattr();

		// Is this field readOnly?
		if($this->isReadOnly()) {
			$code .= ' readonly';
			if(self::isXhtml())
				$code .= '="readonly"';
		}

		// Is this field required AND is HTML5 allowed?
		if(self::isHtml5() && $this->isRequired()) {
			$code .= ' required';
			if(self::isXhtml())
				$code .= '="required"';
		}

		if(! $this->isEnabled()) {
			$code .= ' disabled';
			if(self::isXhtml())
				$code .= '="disabled"';
		} else {
			if($this->isMultipleSelect()) {
				$code .= 'multiple';
				if(self::isXhtml())
					$code .= '="multiple"';
			}
		}
		// Close StartTag
		$code .= '>';

		// Show List
		foreach($this->getSelectList() as $listName => $listValue) {
			$code .= '<option value="' . $listValue . '"';
			if(is_array($this->getValue()) && $this->isMultipleSelect()) {
				foreach($this->getValue() as $value) {
					if($value == $listValue) {
						$code .= ' selected';
						if(self::isXhtml())
							$code .= '="selected"';
						break;
					}
				}
			} else if($listValue == $this->getValue()) {
				$code .= ' selected';
				if(self::isXhtml())
					$code .= '="selected"';
			}
			$code .= '>' . $listName . '</option>';
		}

		// Close Select field
		$code .= '</select>';

		return $code;
	}

	/**
	 * Returns the object as HTML-Code
	 *
	 * @return string - INPUT-HTML-Code
	 */
	private function inputHTML() {
		$code = '<input type="' . $this->getType() . '" name="' . $this->getName() . '" value="' . $this->getValue() . '"';
		$code .= $this->cssIdsHTML() . $this->cssClassesHTML();

		// Add size if its not the default size
		if($this->getSize() !== null)
			$code .= ' size="' . $this->getSize() . '"';

		// Add min length if is set
		if($this->getMinLen() > 0 && self::isHtml5())
			$code .= ' minlength="' . $this->getMinLen() . '"';

		// Add max length if is set
		if($this->getMaxLen() > 0 && self::isHtml5())
			$code .= ' maxlength="' . $this->getMaxLen() . '"';

		// Include other HTML attr
		if($this->getOtherHTMLattr() !== null)
			$code .= ' ' . $this->getOtherHTMLattr();

		// Is this field readOnly?
		if($this->isReadOnly()) {
			$code .= ' readonly';
			if(self::isXhtml())
				$code .= '="readonly"';
		}

		// Is this field required AND is HTML5 allowed?
		if(self::isHtml5() && $this->isRequired()) {
			$code .= ' required';
			if(self::isXhtml())
				$code .= '="required"';
		}

		// Is enabled
		if(! $this->isEnabled()) {
			$code .= ' disabled';
			if(self::isXhtml())
				$code .= '="disabled"';
		}

		// Close input-field
		if(self::isXhtml())
			$code .= ' />';
		else
			$code .= '>';

		return $code;
	}

	/**
	 * Returns the RadioButton/CheckBox as HTML-Code
	 *
	 * @return string - RadioButton/CheckBox HTML-Code
	 */
	private function radioButtonHTML() {
		$code = '<input type="' . $this->getType() . '" name="' . $this->getName() . '" value="' . $this->getValue() . '"';
		$code .= $this->cssIdsHTML() . $this->cssClassesHTML();

		// Include other HTML attr
		if($this->getOtherHTMLattr() !== null)
			$code .= ' ' . $this->getOtherHTMLattr();

		// Is this field readOnly?
		if($this->isReadOnly()) {
			$code .= ' readonly';
			if(self::isXhtml())
				$code .= '="readonly"';
		}

		// Is this field required AND is HTML5 allowed?
		if(self::isHtml5() && $this->isRequired()) {
			$code .= ' required';
			if(self::isXhtml())
				$code .= '="required"';
		}

		// Is checked
		if($this->isChecked()) {
			$code .= ' checked';
			if(self::isXhtml())
				$code .= '="checked"';
		}

		// Is enabled
		if(! $this->isEnabled()) {
			$code .= ' disabled';
			if(self::isXhtml())
				$code .= '="disabled"';
		}

		// Close input-field
		if(self::isXhtml())
			$code .= ' />';
		else
			$code .= '>';

		return $code;
	}

	/**
	 * Returns the TextArea as HTML-Code
	 *
	 * @return string - TextArea HTML-Code
	 */
	private function textAreaHTML() {
		$code = '<textarea name="' . $this->getName() . '"';

		// Add Cols && Rows
		if($this->getCols() !== null)
			$code .= ' cols="' . $this->getCols() . '"';
		if($this->getRows() !== null)
			$code .= ' rows="' . $this->getRows() . '"';

		$code .= $this->cssIdsHTML() . $this->cssClassesHTML();

		if($this->getMinLen() > 0 && self::isHtml5())
			$code .= ' minlength="' . $this->getMinLen() . '"';

		// Add max length if is set
		if($this->getMaxLen() > 0 && self::isHtml5())
			$code .= ' maxlength="' . $this->getMaxLen() . '"';

		// Include other HTML attr
		if($this->getOtherHTMLattr() !== null)
			$code .= ' ' . $this->getOtherHTMLattr();

		// Is this field readOnly?
		if($this->isReadOnly()) {
			$code .= ' readonly';
			if(self::isXhtml())
				$code .= '="readonly"';
		}

		// Is this field required AND is HTML5 allowed?
		if(self::isHtml5() && $this->isRequired()) {
			$code .= ' required';
			if(self::isXhtml())
				$code .= '="required"';
		}

		// Is enabled
		if(! $this->isEnabled()) {
			$code .= ' disabled';
			if(self::isXhtml())
				$code .= '="disabled"';
		}

		// Close open TextArea-Tag and insert value
		$code .= '>' . $this->getValue() . '</textarea>';

		return $code;
	}
}
