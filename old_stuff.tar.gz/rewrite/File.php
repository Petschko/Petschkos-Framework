<?php
/**
 * Author: Peter Dragicevic [peter-91@hotmail.de]
 * Authors-Website: http://petschko.org/
 * Date: 23.09.2015
 * Time: 09:54
 * Update: 09.04.2016
 * Version: 1.0.4 (Changed Class-Name & Website)
 * 1.0.3 (ReFormat code - renaming variables functions change them all to camelCase - Finished documentation)
 *
 * Licence: http://creativecommons.org/licenses/by-sa/4.0/
 *
 * todo rewrite class
 */

// Check if constance is defined - if not define
if(! defined('DS'))
	define('DS', DIRECTORY_SEPARATOR);

/**
 * Class File
 */
class File {
	private static $defaultPerm = '0755';
	private $filename;
	private $name;
	private $path;
	private $fileType;
	private $dir;
	private $fullPath;

	/**
	 * Creates a new file object
	 *
	 * @param string $filePath - Path to the file
	 * @param bool $new - create a new file? true creates a new | false do not create a new
	 * @param bool $overwrite - overwrite existing file? true overwrite existing files | false do not overwrite existing files (only affect on create new)
	 * @param bool $newDir - create a file or a directory? true creates a new directory | false creates a new file (only affect on create new)
	 * @throws Exception - File/directory not found
	 */
	public function __construct($filePath, $new = false, $overwrite = false, $newDir = false) {
		if($new)
			$this->create($filePath, $overwrite, $newDir);
		else
			$this->updateFileInfo($filePath);
	}

	/**
	 * Clears Memory
	 */
	public function __destruct() {
		unset($this->filename);
		unset($this->name);
		unset($this->path);
		unset($this->fileType);
		unset($this->dir);
		unset($this->fullPath);
	}

	/**
	 * Get the Path from a File path (but not get the last end of it) E.g /var/www/myFile.php will return /var/www/
	 *
	 * @param string $path - The File path + file
	 * @return string - The Path to the file (without the file at the end) if there is not a DIRECTORY SEPARATOR in the string return DIRECTORY SEPARATOR
	 */
	public static function getPathFromString($path) {
		$lastSlash = strrpos($path, DS);

		if($lastSlash !== false)
			return substr($path, 0, $lastSlash);
		return DS;
	}

	/**
	 * Ensure, that the last character is a DIRECTORY SEPARATOR
	 *
	 * @param string $path - Path to check
	 * @return string - Path with ensured DIRECTORY SEPARATOR at the end
	 */
	private static function checkDirPath($path) {
		$lastChar = substr($path, -1);
		if($lastChar != DS)
			$path .= DS;

		return $path;
	}

	/**
	 * Creates a new file or directory
	 *
	 * @param string $path - The file path
	 * @param bool $overwrite - Overwrite the file if exists? true overwrite | false don't overwrite (Only affected on create a file)
	 * @param bool $newDir - Create a new directory? true creates a new dir | false creates a new file
	 * @throws Exception - File/Directory not found
	 */
	public function create($path, $overwrite = false, $newDir = false) {
		if($newDir)
			if(! file_exists($path))
				$created = mkdir($path, self::getDefaultPerm(), true);
			else
				$created = true;
		else {
			$created = false;
			if(! file_exists($path) || $overwrite) {
				if(! file_exists(self::getPathFromString($path)))
					new self(self::getPathFromString($path), true, false, true); // Creates missing directories if there are some
				// Create a new empty file
				fclose(fopen($path, 'wb'));
			}
			else
				$created = true;

			if(file_exists($path))
				$created = true;
		}

		// Update file info
		if($created)
			$this->updateFileInfo($path);
		else
			unset($this);
	}

	/**
	 * Rename a file or directory
	 *
	 * @param string $newName - the new name
	 * @return bool - true on success else false
	 * @throws Exception - File/Directory not found
	 */
	public function rename($newName) {
		// "Move" File - Better say rename
		if(rename($this->getFullPath(), $this->getPath() . $newName)) {

			// Update file info
			$this->updateFileInfo($this->getPath() . $newName);

			return true;
		}

		return false;
	}

	/**
	 * Move and may rename a file or directory
	 *
	 * @param string $newPath - The new destination of the file/directory
	 * @param string|bool $newName - The new name | false doesn't change the name
	 * @param bool $overwrite - Overwrites a file/directory if it exists at the destination | false do not overwrite | true overwrite
	 * @return bool - true on success else false
	 * @throws Exception - File/Directory not found
	 */
	public function move($newPath, $newName = false, $overwrite = false) {
		$newPath = self::checkDirPath($newPath);
		$path = $newPath . (($newName) ? $newName : $this->getFilename());

		if(! file_exists($path) || $overwrite) {
			// Delete existing dir if overwrite is allowed
			if($overwrite && file_exists($path) && is_dir($path) && $this->isDir()) {
				$deleteDir = new self($path);
				$deleteDir->delete();
			}

			// Move the file/directory
			$move = rename($this->getFullPath(), $path);

			if($move) {
				// Update File info
				$this->updateFileInfo($path);

				return true;
			}
		}
		return false;
	}

	/**
	 * Copy a file and may rename the new one and may create a new instance
	 *
	 * @param string $newPath - The destination of the copy of the file/directory
	 * @param string|bool $newName - The new name | false doesn't change the name
	 * @param bool $overwrite - Overwrites a file/directory if it exists at the destination | false do not overwrite | true overwrite
	 * @param bool $newResource - Create a new instance of this class for the copy of the file/directory? true does | false not
	 * @return bool|file - true on success else false and "file" on success if $newResource is true
	 */
	public function copy($newPath, $newName = false, $overwrite = false, $newResource = false) {
		$newPath = self::checkDirPath($newPath);
		$path = $newPath . (($newName) ? $newName : $this->getFilename());

		if(! file_exists($path) || $overwrite) {
			// Delete existing dir if overwrite is allowed
			if($overwrite && file_exists($path) && is_dir($path) && $this->isDir()) {
				$deleteDir = new self($path);
				$deleteDir->delete();
			}

			// Copy the file/directory
			if(copy($this->getFullPath(), $path)) {
				if($newResource)
					return new self($path);

				return true;
			}
		}
		return false;
	}

	/**
	 * Deletes the file/directory and remove this instance
	 */
	public function delete() {
		if($this->isDir()) {
			// Delete files and sub folder within the selected folder
			$this->clear();

			// Delete Folder
			rmdir($this->getFullPath());
			clearstatcache();
		} else {
			unlink($this->getFullPath());
			clearstatcache();
		}
		unset($this);
	}

	/**
	 * Get the content of a directory or file (on dir you say 1 file but on files you say 1 byte)
	 *
	 * @param int $limit - how many - on dirs set amount of files | on files set how many bytes
	 * @param int $start - start file (on dirs) or byte (on files)
	 * @param bool $subDirs - only on dirs get content from sub dirs?
	 * @return array|bool - (on dirs) file class array | (on files) false todo implement
	 */
	public function getContent($limit = 1000, $start = 0, $subDirs = false) {
		if($this->isDir()) {
			if($handle = opendir($this->getFullPath())) {
				$array = array();
				$i = 0;
				$ignore = 0;
				while(($file = readdir($handle)) !== false) {
					if($file != '.' && $file != '..') {
						$tmpClass = new self($this->getFullPath() . $file);
						if($ignore >= $start) {
							// Add file/dir to return array
							if(! $tmpClass->isDir() || $subDirs) {
								$array[$i] = $tmpClass;
								$i++;
							}

							// Stop if limit is reached
							if($i >= $limit && $limit > 0) {
								if(is_resource($handle))
									closedir($handle);
								clearstatcache();

								return $array;
							}
						}
						// Increase ignoreCounter and increase it on dirs if enabled
						if(! $tmpClass->isDir() || $subDirs)
							$ignore++;

						// Clear Memory
						unset($tmpClass);
					}
					unset($file);
				}

				// Close handle and clear cache/memory
				unset($ignore);
				if(is_resource($handle))
					closedir($handle);
				clearstatcache();

				return $array;
			}
		} else {
			// todo implement (show file content)
		}

		return false;
	}

	/**
	 * Get the size of a file or directory
	 * ------------------------------------------------------------------------
	 * IMPORTANT: Because PHP's integer type is signed and many platforms use 32bit integers, some filesystem functions
	 * may return unexpected results for files which are larger than 2GB.
	 * See: http://php.net/manual/en/function.filesize.php
	 * ------------------------------------------------------------------------
	 *
	 * @return bool|int - The size of the file/directory (Bytes)
	 */
	public function getSize() {
		if($this->isDir()) {
			$bytes = 0;

			if($handle = opendir($this->getFullPath())) {
				// Count files
				while(($file = readdir($handle)) !== false) {
					if($file != '.' && $file != '..') {
						$tmpClass = new self($this->getFullPath() . $file);

						$bytes += $tmpClass->getSize();

						// Clear Memory
						unset($tmpClass);
					}
					unset($file);
				}
			}

			// Close handle and clear cache
			if(is_resource($handle))
				closedir($handle);
			clearstatcache();

			return $bytes;
		} else
			return filesize($this->getFullPath());
	}

	/**
	 * Get the number of files in this directory
	 *
	 * @param bool $excludeSubDirs - Do not Count files in subdirectories? true doesn't count files in sub dirs | false count files in sub dirs
	 * @param bool $countDirs - Count dirs in the directory too? true counts dirs as the same as files | false ignore dirs on counting
	 * @return int number of files - if the instance is a file this return always 1
	 */
	public function countFiles($excludeSubDirs = true, $countDirs = false) {
		if($this->isDir()) {
			$files = 0;
			if($handle = opendir($this->getFullPath())) {
				// Count files
				while(($file = readdir($handle)) !== false) {
					if($file != '.' && $file != '..') {
						$tmpClass = new self($this->getFullPath() . $file);

						// Is this a dir?
						if($tmpClass->isDir()) {
							// Count sub dirs?
							if($countDirs)
								$files++;

							// Check the content of the sub dirs too?
							if($excludeSubDirs === false)
								$files += $tmpClass->countFiles(false, $countDirs);
						} else
							$files++;

						// Clear Memory
						unset($tmpClass);
					}
					unset($file);
				}
			}
			// Close handle and clear cache
			if(is_resource($handle))
				closedir($handle);
			clearstatcache();

			return $files;
		} else
			return 1; // A File return always 1
	}

	/**
	 * Delete everything in a file or a directory
	 */
	public function clear() {
		if($this->isDir()) {
			if($handle = opendir($this->getFullPath())) {
				// Delete files and sub folder within the selected folder
				while(($file = readdir($handle)) !== false) {
					if($file != '.' && $file != '..') {
						$fileClass = new self($this->getFullPath() . $file);
						$fileClass->delete();
					}
				}

				// Close handle and clear cache
				if(is_resource($handle))
					closedir($handle);
				clearstatcache();
			}
		} else {
			$handle = fopen($this->getFullPath(), 'wb');

			// Close handle and clear cache
			if(is_resource($handle))
				closedir($handle);
			clearstatcache();
		}
	}

	/**
	 * Shows the creation time of a file
	 *
	 * @return int - creation time
	 */
	public function getCTime() {
		return filectime($this->getFullPath());
	}

	/**
	 * Shows the last modification time of a file
	 *
	 * @return int modification time
	 */
	public function getMTime() {
		return filemtime($this->getFullPath());
	}

	/**
	 * Changes the permission of a file or directory
	 *
	 * @param string|bool $perm - Permissions as a string or false if restoring the files default permissions
	 * @return bool - true on success else false
	 */
	public function chmod($perm = false) {
		return chmod($this->getFullPath(), ((is_string($perm)) ? octdec($perm) : self::getDefaultPerm()));
	}

	/**
	 * Update the information about this file/directory in this instance
	 *
	 * @param string $filePath - path of the file/directory MUST exist!
	 * @throws Exception - File/Directory not found
	 */
	private function updateFileInfo($filePath) {
		if(! file_exists($filePath))
			throw new Exception(__CLASS__ . '->' . __FUNCTION__ . ': &quot;' . $filePath . '&quot; doesn\'t exists!');

		$lastSlash = strrpos($filePath, DS);
		$this->setFullPath($filePath);
		if(is_dir($this->getFullPath())) {
			$this->setDir(true);
			$this->setFileType('DIRECTORY');

			// Check if last char is an slash if yes recheck to the previous slash
			$lastChar = substr($this->getFullPath(), -1);
			if($lastChar == DS) {
				$filePath = substr($filePath, 0, -1);
				$lastSlash = strrpos($filePath, DS);
			} else
				$this->setFullPath($this->getFullPath() . DS);
			unset($lastChar);

			// Get path and directory name
			if($lastSlash !== false) {
				$this->setPath(substr($this->getFullPath(), 0, $lastSlash + 1));
				$this->setFilename(substr($this->getFullPath(), $lastSlash + 1));
			} else {
				$this->setPath($this->getFullPath());
				$this->setFilename($this->getFullPath());
			}

			// Check if filename not end with slash
			$lastChar = substr($this->getFilename(), -1);
			if($lastChar == DS)
				$this->setFilename(substr($this->getFilename(), 0, -1));
			$this->setName($this->getFilename());
		} else {
			$this->setDir(false);

			// Get Filename
			if($lastSlash !== false) {
				$this->setPath(substr($filePath, 0, $lastSlash + 1));
				$file = substr($this->getFullPath(), $lastSlash + 1);
			} else {
				$this->setPath($this->getFullPath());
				$file = $this->getFullPath();
			}
			$this->setFilename($file);

			$lastDot = stripos($file, '.');
			if($lastDot !== false) {
				$this->setName(substr($file, 0, $lastDot));
				$this->setFileType(strtolower(substr($file, $lastDot + 1)));
			} else {
				$this->setName($this->getFilename());
				$this->setFileType('NONE');
			}
		}
	}

	/**
	 * Get the Full-Path of the file or directory
	 *
	 * @return string - the path to the file/directory including the name of the dir/file
	 */
	public function getFullPath() {
		return $this->fullPath;
	}

	/**
	 * Set the Full-Path of the file or directory
	 *
	 * @param string $fullPath - the path to the file/directory including the name of the dir/file
	 */
	private function setFullPath($fullPath) {
		$this->fullPath = $fullPath;
	}

	/**
	 * Get the name of the file plus extension eg "index.php" or a directory
	 *
	 * @return string - The File name
	 */
	public function getFilename() {
		return $this->filename;
	}

	/**
	 * Set the name of the file plus extension eg "index.php" or a directory
	 *
	 * @param string $filename - The File name
	 */
	private function setFilename($filename) {
		$this->filename = $filename;
	}

	/**
	 * Get the name of the file without extension eg "index" instead of "index.php" or a directory
	 *
	 * @return string - The name
	 */
	public function getName() {
		return $this->name;
	}

	/**
	 * Set the name of the file without extension eg "index" instead of "index.php" or a directory
	 *
	 * @param string $name - The name
	 */
	private function setName($name) {
		$this->name = $name;
	}

	/**
	 * Get the Path to the file but without the filename itself or the path to the directory without the dir itself
	 *
	 * @return string - The Path to the dir/file
	 */
	public function getPath() {
		return $this->path;
	}

	/**
	 * Set the Path to the file but without the filename itself or the path to the directory without the dir itself
	 *
	 * @param string $path - The Path to the dir/file
	 */
	private function setPath($path) {
		$this->path = $path;
	}

	/**
	 * Get the File type of this instance
	 *
	 * @return string - file type of the file or "NONE" or "DIRECTORY"
	 */
	public function getFileType() {
		return $this->fileType;
	}

	/**
	 * Set the File type of this instance
	 *
	 * @param string $fileType - file type
	 */
	private function setFileType($fileType) {
		$this->fileType = $fileType;
	}

	/**
	 * @return bool - true if this instance is a directory else false
	 */
	public function isDir() {
		return $this->dir;
	}

	/**
	 * @param bool $dir - is this a directory? true is a directory | false is not a directory
	 */
	private function setDir($dir) {
		$this->dir = $dir;
	}

	/**
	 * Get the default permissions
	 *
	 * @return number - Default Permissions for chmod and functions that need permissions
	 */
	public static function getDefaultPerm() {
		return octdec(self::$defaultPerm);
	}

	/**
	 * Set the default permissions
	 *
	 * @param string $defaultPerm - Default Permissions for chmod and functions that need permissions
	 */
	public static function setDefaultPerm($defaultPerm) {
		self::$defaultPerm = $defaultPerm;
	}
}
