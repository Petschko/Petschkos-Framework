<?php
/**
 * Author: Peter Dragicevic [peter-91@hotmail.de]
 * Authors-Website: http://petschko.org/
 * Licence: http://creativecommons.org/licenses/by-sa/4.0/
 * Date: 20.07.2015
 * Time: 09:46
 * Update: 09.04.2016
 * Version: 1.0.5 (Changed Class-Name & Website)
 * 1.0.4 (Fixed Protocol-Remove under Windows hosts remove :// instead of : - Code Reformat - fixed all around "instance" - make it static to access it)
 * 1.0.3 (Changed static Charset on htmlspecialchars to config::charset)
 *
 * Notes: Switches between different Languages
 * todo use an other method to switch langs
 */

// Variable need to storage the different languages
if(! isset($lang))
	$lang = array();
// Check if constance is defined - if not define
if(! defined('DS'))
	define('DS', DIRECTORY_SEPARATOR);

/**
 * Class Lang
 *
 * Single-Instance-Class
 */
class Lang {
	private static $instance;
	private $lang;

	/**
	 * Crates this instance
	 *
	 * @param string $userLang - selected language
	 */
	public function __construct($userLang) {
		if(! $this->getInstance()) {
			$cookie = $this->getLangCookie($userLang);
			if($userLang == '' && ! $cookie)
				$this->setLang(Config::defaultLang);
			else if($cookie)
				$this->setLang($cookie);
			else {
				$this->setLang($userLang);
				$this->setLangCookie($userLang);
			}
			self::setInstance($this);
		}
	}

	/**
	 * Save include a PHP-file
	 *
	 * @param string $filePath - Path to the file
	 * @param string $filename - Filename
	 * @return mixed - Include-File
	 * @throws Exception - File not found 404
	 */
	private static function saveInclude($filePath, $filename) {
		$cleanFilename = basename($filename, '.php');
		$cleanFilename = str_replace('/', '', $cleanFilename); // For fallback
		$cleanFilename = str_replace(DS, '', $cleanFilename);

		$filePath = str_replace('://', '', $filePath); // Remove protocol

		if(file_exists($filePath . $cleanFilename . '.php'))
			return require_once($filePath . $cleanFilename . '.php');
		else
			throw new Exception(
				self::display('exception_save_include_404',
					array(
						'file' => $filePath . $cleanFilename . '.php',
						'class' => (string) __CLASS__,
						'function' => (string) __FUNCTION__
					)
				));
	}

	/**
	 * Display the var in the correct language
	 *
	 * @param string $localeName - name of the var
	 * @param array $array - params to replace
	 * @return string - locale string with replaced vars
	 */
	public static function display($localeName, $array = array()) {
		global $lang; // Lang var outside the class

		// Check if the var exists
		if(! isset($lang[$localeName]))
			return '[LANG-VAR missing: "' . $localeName . '"]';
		$string = $lang[$localeName];

		// Replace values
		if(mb_substr_count($string, '%') > 0) {
			foreach($array as $key => $value) {
				$string = str_replace('%' . $key . '%', $value, $string);
			}
		}

		return $string;
	}

	/**
	 * Returns a static language html file
	 *
	 * @param string $loc - destination file
	 * @param string $from - path to file
	 * @return mixed - Return files
	 */
	public function requireLocaleFile($loc, $from = null) {
		if(mb_stripos($loc, '_', 0))
			$loc = mb_substr(mb_strrchr($loc, '_'), 1);

		if($from === null)
			$from = HTMLDIR . DS . 'content' . DS;

		// Add DS to end ot the path if not exists
		if(mb_substr($from, -1) != DS)
			$from .= DS;

		if(file_exists($from . basename($loc . '.php'))) {
			// Exists locale file?
			if(file_exists($from . basename($loc . '.' . $this->getLocale() . '.php')))
				return self::saveInclude($from, $loc . '.' . $this->getLocale());

			// Return default file
			return self::saveInclude($from, $loc);
		}

		// 404 File not found
		return require_once(HTMLDIR . DS . '404.html');
	}

	/**
	 * Check if the language exists, if not return default language
	 *
	 * @return string - shows current user language on error show default lang
	 */
	public function getLocale() {
		foreach(Config::$enabledLanguages as $value) {
			if($value == $this->getLang())
				return $this->getLang();
		}

		// If not found in enabled lang show default
		return Config::defaultLang;
	}

	/**
	 * Returns a pointer of this instance
	 *
	 * @return Lang - get a pointer of the class instance
	 */
	public static function &getInstance() {
		return self::$instance;
	}

	/**
	 * Set this instance
	 *
	 * @param Lang $instance - set class instance
	 */
	private static function setInstance($instance) {
		self::$instance = $instance;
	}

	/**
	 * Returns the current set language
	 *
	 * @return string - get the lang of this class
	 */
	public function getLang() {
		return $this->lang;
	}

	/**
	 * Set the current language
	 *
	 * @param string $lang - set the lang of this class
	 */
	private function setLang($lang) {
		$this->lang = $lang;
	}

	/**
	 * Try to read a language cookie and return it
	 *
	 * @param string $getLang - language
	 * @return bool|string - false on no-cookie, cookie value on cookie
	 */
	private function getLangCookie($getLang) {
		if(class_exists('cookie')) {
			if(cookie::getCookie('locale') === false)
				return false;

			if($getLang != '' && $getLang != cookie::getCookie('locale', $getLang)) {
				$this->setLangCookie($getLang);
				return false;
			}

			return cookie::getCookie('locale', $getLang);
		} else {
			if(! isset($_COOKIE['locale']))
				$_COOKIE['locale'] = null;

			if($getLang != '' && $getLang != $_COOKIE['locale']) {
				$this->setLangCookie($getLang);
				return false;
			}

			return $_COOKIE['locale'];
		}
	}

	/**
	 * Set an user language Cookie
	 *
	 * @param $user_lang - language
	 */
	private function setLangCookie($user_lang = Config::defaultLang) {
		// Locale Cookies expires after 3 months
		if(class_exists('cookie'))
			cookie::setcookie('locale', $user_lang, time() + 7776000);
		else
			setcookie('locale', $user_lang, time() + 7776000);
	}
}
