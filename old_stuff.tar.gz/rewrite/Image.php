<?php
/**
 * Author: Peter Dragicevic [peter-91@hotmail.de]
 * Authors-Website: http://petschko.org/
 * Date: 04.08.2015
 * Time: 14:52
 * Update: 09.04.2016
 * Version: 1.0.2 (Changed Class-Name & Website)
 *
 * Licence: http://creativecommons.org/licenses/by-sa/4.0/
 * Notes: todo improve whole class
 */

/**
 * Class Image
 */
class Image {
	private $path;
	private $image_dir;
	private $image_name;
	private $image_ext;
	private $image = false;
	private $height;
	private $width;
	private $type;
	private static $allowed_ext = array('png', 'gif', 'jpeg', 'jpg');

	/**
	 * Creates a new instance
	 *
	 * @param string $path - path of the image
	 * @param string|bool $type - Type of the new image
	 * @param int|bool $new_height - Height of the new image
	 * @param int|bool $new_width - Width of the new image
	 * @param bool $new - Create an new image? Set true to make sure that this get a new image
	 * @throws Exception - Image type not supported
	 */
	public function __construct($path, $type = false, $new_height = false, $new_width = false, $new = false) {
		// Set Path infos
		$path = str_replace('/', DS, $path);
		$this->setPath($path);
		$this->setImageDir($path);
		$this->setImageName($path);
		$this->setImageExt($path);

		if(file_exists($path) && $new === false) {
			$details = getimagesize($this->getPath());
			$this->setType($details[2]);
			$this->setHeight($details[1]);
			$this->setWidth($details[0]);
			unset($details);

			// Load image
			$this->loadImg();
		} else if($type !== false) {
			$this->setType($type);
			$this->setHeight($new_height);
			$this->setWidth($new_width);

			// Create new image
			$this->createImg();
		}
	}

	/**
	 * Clears Memory
	 */
	public function __destruct() {
		unset($this->path);
		unset($this->image_dir);
		unset($this->image_name);
		unset($this->image_ext);
		unset($this->height);
		unset($this->width);
		unset($this->type);

		// Delete image
		imagedestroy($this->getImage());
		unset($this->image);
	}

	/**
	 * Returns the name of the image without extension
	 *
	 * @return string - Image name without extension
	 */
	public function getImageName() {
		return $this->image_name;
	}

	/**
	 * Set the name of the image (without ext)
	 *
	 * @param string $image_name - path or filename with extension OR filename without extension
	 */
	private function setImageName($image_name) {
		if(mb_strripos($image_name, DS) !== false) {
			$filename = mb_substr($image_name, mb_strripos($image_name, DS) + 1);
			if(mb_strripos($image_name, '.') !== false)
				$this->image_name = mb_substr($filename, 0, mb_strripos($filename, '.') - 1);
			else
				$this->image_name = $filename;
		} else
			$this->image_name = $image_name;
	}

	/**
	 * Get the image extension (dot included)
	 *
	 * @return string - extension of the filename (with ".")
	 */
	public function getImageExt() {
		return $this->image_ext;
	}

	/**
	 * Set the image extension based on the path or filename - sets invalid.dist if there is no extension
	 *
	 * @param string $image_ext - path or filename or extension of the image file
	 */
	private function setImageExt($image_ext) {
		if(mb_strripos($image_ext, DS) !== false)
			$image_ext = mb_substr($image_ext, mb_strripos($image_ext, DS) + 1);

		if(mb_strripos($image_ext, '.') !== false)
			$this->image_ext = mb_strtolower(mb_substr($image_ext, mb_strripos($image_ext, '.')));
		else
			$this->image_ext = 'invalid.dist';
	}

	/**
	 * Returns the path to the image including the image name plus extension
	 *
	 * @return string - Full Image path
	 */
	public function getPath() {
		return $this->path;
	}

	/**
	 * Set the path to the image including the image name plus extension
	 *
	 * @param string $path - Full Image path
	 */
	private function setPath($path) {
		$this->path = $path;
	}

	/**
	 * Returns the image resource of this object
	 *
	 * @return resource - resource of the image in memory
	 */
	public function getImage() {
		return $this->image;
	}

	/**
	 * Set a image resource to this object
	 *
	 * @param resource $image - the image resource
	 */
	private function setImage($image) {
		$this->image = $image;
	}

	/**
	 * returns the height of this images
	 *
	 * @return int - height of the image
	 */
	public function getHeight() {
		return $this->height;
	}

	/**
	 * Set the height og this image
	 *
	 * @param int $height - height of the image
	 */
	private function setHeight($height) {
		$this->height = $height;
	}

	/**
	 * Returns the width of this image
	 *
	 * @return int - width of the image
	 */
	public function getWidth() {
		return $this->width;
	}

	/**
	 * Set the width of this image
	 *
	 * @param int $width - width of the image
	 */
	private function setWidth($width) {
		$this->width = $width;
	}

	/**
	 * Returns the image type of this image
	 *
	 * @return mixed type of the image
	 */
	public function getType() {
		return $this->type;
	}

	/**
	 * Set the image type of this image
	 *
	 * @param mixed $type type of the image
	 */
	private function setType($type) {
		if(is_int($type))
			$this->type = $type;
		else
			$this->setType(self::get_valid_type($type));
	}

	/**
	 * Returns the path to the image but not the image-file itself
	 *
	 * @return string - the directory path where the image is
	 */
	public function getImageDir() {
		return $this->image_dir;
	}

	/**
	 * Set the path to the image but not the filename itself
	 *
	 * @param string $image_dir - path where the image is, can be the full path to, we try to convert it
	 */
	private function setImageDir($image_dir) {
		if(mb_strripos($image_dir, DS) !== false) {
			$this->image_dir = mb_substr($image_dir, 0, mb_strripos($image_dir, DS));
		} else
			$this->image_dir = '.' . DS;
	}

	/**
	 * Loads an image into memory
	 *
	 * @throws Exception - Image-Type not found
	 */
	private function loadImg() {
		// Better use IMAGETYPE - IMG_ returns may a wrong value
		switch($this->getType()) {
			//case IMG_JPG:
			//case IMG_JPEG:
			case IMAGETYPE_JPEG:
				$this->setImage(imagecreatefromjpeg($this->getPath()));
				break;
			//case IMG_PNG:
			case IMAGETYPE_PNG:
				$this->setImage(imagecreatefrompng($this->getPath()));
				break;
			//case IMG_GIF:
			case IMAGETYPE_GIF:
				$this->setImage(imagecreatefromgif($this->getPath()));
				break;
			default:
				throw new Exception('Image Type ' . $this->getType() . ' is not supported in class ' . __CLASS__ . ' for your image: ' . $this->getPath());
		}
	}

	/**
	 * Creates a new image
	 */
	private function createImg() {
		if($this->getHeight() > 0 && $this->getWidth() > 0) {
			if(function_exists('imagecreatetruecolor'))
				$this->setImage(imagecreatetruecolor($this->getWidth(), $this->getHeight()));
			else
				$this->setImage(imagecreate($this->getWidth(), $this->getHeight()));
		}
	}

	/**
	 * Get an valid image type from string
	 *
	 * @param string $type_string - extension of the image
	 * @return bool|int - false or the image type
	 * @throws Exception - MultiByte functions not found
	 */
	public static function get_valid_type($type_string) {
		if(function_exists('mb_strripos') && function_exists('mb_strripos')) {
			$type_string = mb_strtolower($type_string);
			if (mb_strripos($type_string, '.'))
				$type_string = mb_substr($type_string, mb_strripos($type_string, '.') + 1);

			if(in_array($type_string, self::$allowed_ext)) {
				switch($type_string) {
					case 'jpg':
					case 'jpeg':
						//return IMG_JPEG;
						return IMAGETYPE_JPEG;
					case 'png':
						//return IMG_PNG;
						return IMAGETYPE_PNG;
					case 'gif':
						//return IMG_GIF;
						return IMAGETYPE_GIF;
				}
			}
			// Default value
			return false;
		} else
			throw new Exception('Please make sure, that you have installed the MultiBytes functions!');
	}

	/**
	 * Save the current image to...
	 *
	 * @param string|bool $path - path where the image will be saved - on false use the image dir (this->getdir)
	 * @param string|int|bool $type - image type, as what the image should be saved
	 * @return bool - true on success
	 */
	public function saveImg($path = false, $type = false) {
		if(! $path)
			$path = $this->getPath();

		if(is_string($type))
			$type = self::get_valid_type($type);
		else if(! $type)
			$type = $this->getType();

		$saved = false;
		switch($type) {
			case IMAGETYPE_JPEG:
			//case IMG_JPG:
			//case IMG_JPEG:
				$saved = imagejpeg($this->getImage(), $path);
				break;
			case IMAGETYPE_PNG:
			//case IMG_PNG:
				$saved = imagepng($this->getImage(), $path);
				break;
			case IMAGETYPE_GIF:
			//case IMG_GIF:
				$saved = imagegif($this->getImage(), $path);
				break;
		}

		return $saved;
	}

	/**
	 * Resize an image
	 *
	 * @param int $new_height - height of the the new image
	 * @param int $new_width - width of the new image
	 * @param string|bool $focus_dimension - if you doesn't want to lose the aspect ratio, set which "new" value should be ignored or set this to false to scale the image from both dimensions
	 * @param string|int|bool $new_type - type of the new image on false we use the type of the original image
	 * @return bool|image - false on error on success the new image ressource
	 */
	public function resizeImg($new_height = 0, $new_width = 0, $focus_dimension = false, $new_type = false) {
		switch($focus_dimension) {
			case 'width':
				$factor = $this->getWidth() / $new_width;
				if($factor < 1)
					$new_height = (int) ceil($this->getHeight() * $factor);
				else
					$new_height = (int) ceil($this->getHeight() / $factor);
				break;
			case 'height':
				$factor = $this->getHeight() / $new_height;
				if($factor < 1)
					$new_width = (int) ceil($this->getWidth() * $factor);
				else
					$new_width = (int) ceil($this->getWidth() / $factor);
				break;
		}

		if(is_string($new_type))
			$new_type = self::get_valid_type($new_type);
		else if(! $new_type)
			$new_type = $this->getType();

		if($new_height <= 0 || $new_width <= 0)
			return false;

		$tmp_img_path = $this->getImageDir() . DS . $this->getImageName() . '_tmp' . time() . $this->getImageExt();

		// Create new image
		$new_image = new image($tmp_img_path, $new_type, $new_height, $new_width, true);

		// Resize
		imagecopyresampled($new_image->getImage(), $this->getImage(), 0, 0, 0, 0, $new_width, $new_height, $this->getWidth(), $this->getHeight());

		return $new_image;
	}

	/**
	 * Resize image and cut away overlaying borders, so that the proportions are the same as before
	 *
	 * todo improve
	 *
	 * @param int $new_height - height of the new image
	 * @param int $new_width - width of the new image
	 * @param bool $new_type - type of the new image on default use the current image type of the "old" image
	 * @return image - center cutted image
	 */
	public function centerCutImg($new_height = 0, $new_width = 0, $new_type = false) {
		$start_height = 0;
		$start_width = 0;

		// Detect new factor
		if($new_height > $new_width) {
			$new_factor = $new_height / $new_width;
			$new_big_side = 'height';
		} else {
			$new_factor = $new_width / $new_height;
			$new_big_side = 'width';
		}

		// Detect image factor
		if($this->getHeight() > $this->getWidth()) {
			$factor = $this->getHeight() / $this->getWidth();
			$big_side = 'height';
		} else {
			$factor = $this->getWidth() / $this->getHeight();
			$big_side = 'width';
		}

		// Check if factor matches, if not make correction
		if($factor != $new_factor || $new_big_side != $big_side) {
			unset($factor);
			// Set default height/width
			$tmp_height = $this->getHeight();
			$tmp_width = $this->getWidth();

			// Calc sizes
			// Calc down if image sizes are bigger than dest sizes
			$bigger = false;
			while($new_height < $tmp_height && $new_width < $tmp_width) {
				if($big_side == 'height') {
					$tmp_width--;
					$tmp_height = $tmp_height - (1 / $new_factor);
				} else {
					$tmp_height--;
					$tmp_width = $tmp_width - (1 / $new_factor);
				}
				$bigger = true;
			}

			// Calc up image, if its smaller than dest img
			while(($new_height > $tmp_height || $new_width > $tmp_width) && ! $bigger) {
				if($big_side == 'height') {
					$tmp_width++;
					$tmp_height = $tmp_height + (1 / $new_factor);
				} else {
					$tmp_height++;
					$tmp_width = $tmp_width + (1 / $new_factor);
				}
			}

			// Resize image to size
			$new_img = $this->resizeImg((int) floor($tmp_height), (int) floor($tmp_width), false, $new_type);

			// Calc Start Positions
			$height_diff = $new_height - $tmp_height;
			if($height_diff < 0)
				$height_diff = $height_diff * -1;
			if($height_diff != 0)
				$start_height = (int) ceil($height_diff / 2);

			$width_diff = $new_width - $tmp_width;
			if($width_diff < 0)
				$width_diff = $width_diff * -1;
			if($width_diff != 0)
				$start_width = (int) ceil($width_diff / 2);

			// Cut of overlapping pixels and overwrite current img
			return $new_img->cutImage($start_height, $start_width, $tmp_height - $height_diff, $tmp_width - $width_diff, $new_type);
		}

		// Resize and return new image
		return $this->resizeImg($new_height, $new_width, false, $new_type);
	}

	/**
	 * Cut an image on the specific coordinates
	 *
	 * @param int $start_height - height, where you want to start cutting
	 * @param int $start_width - width, where you want to start cutting
	 * @param int $new_height - height of the new image
	 * @param int $new_width - width of the new image
	 * @param bool $new_type - type of the new image on default use the type of the "old" image
	 * @return image - cutted image
	 */
	public function cutImage($start_height = 0, $start_width = 0, $new_height = 1, $new_width = 1, $new_type = false) {
		if(is_string($new_type))
			$new_type = self::get_valid_type($new_type);
		else if(! $new_type)
			$new_type = $this->getType();

		$new_image = new image($this->getImageDir() . DS . $this->getImageName() . '_tmp_cutImg' . time() . $this->getImageExt(), $new_type, $new_height, $new_width, true);

		imagecopy($new_image->getImage(), $this->getImage(), 0, 0, $start_width, $start_height, $new_width, $new_height);

		return $new_image;
	}

	/**
	 * Add an text to the image
	 *
	 * @param int $start_height - height, where you want to start to place the text
	 * @param int $start_width - width where you want to start the text
	 * @param string $text - The text
	 * @param array $color_rgb - color RGB array
	 * @param int $font_size - size of the text
	 * @param string $ttf - font type
	 * @param int $angle - angle
	 * @param bool $ignore - ignore when the text is larger than the image
	 * @return array|bool - All four corners of the text with and height (8 object array) See: http://php.net/imagettftext | false on error
	 * @throws Exception - Can't draw
	 */
	public function addText($start_height = 0, $start_width = 0, $text = "", $color_rgb = array(0, 0, 0), $font_size = 12, $ttf = 'ARIAL', $angle = 0, $ignore = false) {
		if(! function_exists('imagettftext') || ! function_exists('imageftbbox'))
			throw new Exception('Cannot draw Text on Image, Functions doesn\'t exists!...');

		// Get Text-Size informations
		$positions = imageftbbox($font_size, $angle, $ttf, $text);

		// Add Start values to positions
		$positions[0] = $positions[0] + $start_width;
		$positions[1] = $positions[1] + $start_height;
		$positions[2] = $positions[2] + $start_width;
		$positions[3] = $positions[3] + $start_height;
		$positions[4] = $positions[4] + $start_width;
		$positions[5] = $positions[5] + $start_height;
		$positions[6] = $positions[6] + $start_width;
		$positions[7] = $positions[7] + $start_height;

		// Check if text overlaps image borders
		if(! $ignore) {
			if ($positions[1] > $this->getHeight() || $positions[2] > $this->getWidth() || $positions[3] > $this->getHeight() || $positions[4] > $this->getWidth())
				return false;
			if ($positions[0] < 0 || $positions[5] < 0 || $positions[6] < 0 || $positions[7] < 0)
				return false;
		}

		return imagettftext($this->getImage(), $font_size, $angle, $start_width, $start_height, $this->RGB($color_rgb[0], $color_rgb[1], $color_rgb[2]), $ttf, $text);
	}

	/**
	 * Returns the with & height of a single Character
	 *
	 * @param string $char - Character
	 * @param int $font_size - Size of the text
	 * @param string $ttf - font type
	 * @return array - height and width of the character
	 */
	public static function getCharWidth($char, $font_size = 12, $ttf = 'ARIAL') {
		$sizes = imageftbbox($font_size, 0, $ttf, $char);

		return array('h' => $sizes[3], 'w' => $sizes[2]);
	}

	/**
	 * Returns an RGB-Color
	 *
	 * @param int $r - Red 0 - 255
	 * @param int $g - Green 0 - 255
	 * @param int $b - Blue 0 - 255
	 * @return int|bool - The Color identifier | false on error
	 */
	private function RGB($r = 0, $g = 0, $b = 0) {
		return ImageColorAllocate($this->getImage(), $r, $g, $b);
	}

	/**
	 * Returns an RGBA-Color
	 *
	 * @param int $r - Red 0 - 255
	 * @param int $g - Green 0 - 255
	 * @param int $b - Blue 0 - 255
	 * @param int $a - Alpha (Opacity) 0 - 127
	 * @return int|bool - The Color identifier | false on error
	 */
	private function RGBA($r =0, $g = 0, $b = 0, $a = 127) {
		return imagecolorallocatealpha($this->getImage(), $r, $g, $b, $a);
	}

	/**
	 * Fill the Background of the Image with an specific color
	 *
	 * @param array $color - Color array
	 * @return bool - true on success and false on error
	 */
	public function fillBG($color = array(0, 0, 0)) {
		if(count($color) == 3)
			return imagefill($this->getImage(), 0, 0, $this->RGB($color[0], $color[1], $color[2]));
		else {
			$tmp_color = $this->RGB($color[0], $color[1], $color[2]);
			imagecolortransparent($this->getImage(), $tmp_color);
			return imagefill($this->getImage(), 0, 0, $this->RGBA($color[0], $color[1], $color[2], $color[3]));
		}
	}

	/**
	 * Shows an image directly (HTML)
	 *
	 * @param string $alt_msg - Message if the image can't be shown
	 * @throws Exception - image type not supported
	 */
	public function showImage($alt_msg = 'Image') {
		// Create Image
		switch($this->getType()) {
			case IMAGETYPE_JPEG:
			//case IMG_JPG:
			//case IMG_JPEG:
				// Start Buffering
				ob_start();

				imagejpeg($this->getImage());

				// Get Buffer and delete it
				$bytes = ob_get_clean();
				$type = 'jpeg';
				break;
			case IMAGETYPE_PNG:
			//case IMG_PNG:
				// Start Buffering
				ob_start();

				imagepng($this->getImage());

				// Get Buffer and delete it
				$bytes = ob_get_clean();
				$type = 'png';
				break;
			case IMAGETYPE_GIF:
			//case IMG_GIF:
				// Start Buffering
				ob_start();

				imagegif($this->getImage());

				// Get Buffer and delete it
				$bytes = ob_get_clean();
				$type = 'gif';
				break;
			default:
				ob_end_clean();
				throw new Exception('Image type is not supported!');
		}

		echo "<img src=\"data:image/{$type};base64," . base64_encode($bytes) . "\" alt=\"{$alt_msg}\">";
	}

	/**
	 * Add an other image on top/below of this image
	 *
	 * @param image $image - the new image object
	 * @param bool $above - is the new image above or below the old image (true = above | false = below)
	 * @param bool $new_type - new type of the image
	 * @return image - new image
	 * @throws Exception - Image is not an object nor an image object
	 */
	public function add_image($image, $above = true, $new_type = false) {
		if(is_string($new_type))
			$new_type = self::get_valid_type($new_type);
		else if(! $new_type)
			$new_type = $this->getType();

		if(gettype($image) != 'object')
			throw new Exception(__CLASS__ . '->' .__FUNCTION__ . ': Image is not an Object');
		if(get_class($image) != 'image')
			throw new Exception(__CLASS__ . '->' .__FUNCTION__ . ': Image is not an Image Object');

		if($above) {
			$new_height = $this->getHeight();
			$new_width = $this->getWidth();
			$destimg = $this;
			$srcimg = $image;
		} else {
			$new_height = $image->getHeight();
			$new_width = $image->getWidth();
			$destimg = $image;
			$srcimg = $this;
		}

		ImageCopy($destimg->getImage(), $srcimg->getImage(), 0, 0, 0, 0, $srcimg->getWidth(), $srcimg->getHeight());

		return $destimg;
	}
}
