<?php
/**
 * Author: Peter Dragicevic [peter-91@hotmail.de]
 * Authors-Website: http://petschko.org/
 * Date: 25.11.2015
 * Time: 12:45
 * Update: 09.04.2016
 * Version: 1.1.4 (Changed Website)
 * 1.1.3 (Reformat Code)
 *
 * Notes: Create Forms with this class
 * todo rewrite
 */

/**
 * Class Form
 */
class Form_old2 {
	private $fields = array();
	private $name;
	private $returnMsg;
	private $isPost;
	private $upload;

	/**
	 * Create a new instance of forms
	 *
	 * @param array $fields - object array of form objects
	 * @param string $name - name of the form
	 * @param bool|string $returnMsg - return message for the user - false means no message
	 * @param bool $isPost - set the method true = post false = get
	 * @param bool $uploadForm - set this to true if you uploading some with this form
	 */
	public function __construct($fields, $name, $returnMsg = false, $isPost = true, $uploadForm = false) {
		$this->setFields($fields);
		$this->setName($name);
		$this->setReturnMsg($returnMsg);
		$this->setIsPost($isPost);
		$this->setUpload($uploadForm);
		$this->setField('formName', FormField_old::createNewField('formName', 'hidden', $name, $isPost));
	}

	/**
	 * Clears Memory
	 */
	public function __destruct() {
		unset($this->fields);
		unset($this->name);
		unset($this->returnMsg);
		unset($this->isPost);
		unset($this->upload);
	}

	/**
	 * Returns the Fields array
	 *
	 * @return array - get the object array of the form
	 */
	private function getFields() {
		return $this->fields;
	}

	/**
	 * Set the Field array
	 *
	 * @param array $fields - set the object array of the form
	 */
	private function setFields($fields) {
		$this->fields = $fields;
	}

	/**
	 * Get the Name
	 *
	 * @return string - the name of the form
	 */
	public function getName() {
		return $this->name;
	}

	/**
	 * Set the Name
	 *
	 * @param string $name - set the name of the form
	 */
	private function setName($name) {
		$this->name = $name;
	}

	/**
	 * Get the current message of the form object
	 *
	 * @return string|bool - the (error/success) message of the form - false means no message
	 */
	public function getReturnMsg() {
		return $this->returnMsg;
	}

	/**
	 * Setup an error/success message
	 *
	 * @param string|bool $returnMsg - set the return message for the user - false means no message
	 */
	public function setReturnMsg($returnMsg) {
		$this->returnMsg = $returnMsg;
	}

	/**
	 * Get an field object
	 *
	 * @param string $fieldName - name of the field
	 * @return FormField - field object
	 */
	public function getField($fieldName) {
		return $this->fields[$fieldName];
	}

	/**
	 * Set a new field object or overwrite it
	 *
	 * @param string $fieldName - name of the field object
	 * @param FormField $object - the field object
	 */
	public function setField($fieldName, $object) {
		$this->fields[$fieldName] = $object;
	}

	/**
	 * Get isPost (Method type of this class)
	 *
	 * @return bool - the method of the form get = false | post = true
	 */
	public function getIsPost() {
		return $this->isPost;
	}

	/**
	 * Set isPost (Method type of this class)
	 *
	 * @param bool $isPost - the method of the form get|post
	 */
	private function setIsPost($isPost) {
		$this->isPost = $isPost;
	}

	/**
	 * Get is Upload
	 *
	 * @return bool - is this an upload form = true | not = false
	 */
	public function isUpload() {
		return $this->upload;
	}

	/**
	 * Set isUpload
	 *
	 * @param bool $upload - is this an upload form = true | no = false
	 */
	private function setUpload($upload) {
		$this->upload = $upload;
	}

	/**
	 * Check if the Form was submitted
	 *
	 * @return bool - is this form send by post/get = true | false = not send
	 */
	public function isSend() {
		if($this->getIsPost()) {
			if(! isset($_POST['formName']))
				$_POST['formName'] = false;

			// Check if form is send
			if($_POST['formName'] == $this->getName())
				return true;
			return false;
		} else {
			if(! isset($_GET['formName']))
				$_GET['formName'] = false;

			// Check if form is send
			if($_GET['formName'] == $this->getName())
				return true;
			return false;
		}
	}

	/**
	 * Checks all fields in this Form, if they're filled out correctly
	 *
	 * @return array|bool - error array (errorFieldName, errorReason[, optional info like maxLen etc]) or true on success
	 */
	public function checkValues() {

		// Check all vars if they are filled out correctly
		/**
		 * @var FormField $field - FormField
		 */
		foreach($this->getFields() as $field) {

			// Trim data
			$field->setValue(trim($field->getValue()));

			// Check if var is filled out, if required
			if($field->isRequired() && ! $field->getValue())
				return array($field->getName(), 'required');

			// Check if text is to long
			if($field->getMaxLen() < $field->getCurrentLen() && $field->getMaxLen() != 0)
				return array($field->getName(), 'maxlen', $field->getMaxLen());

			// Check if field is to short (only on req fields)
			if($field->getMinLen() > $field->getCurrentLen() && ($field->isRequired() || $field->getCurrentLen() > 0) && $field->getMinLen() != 0)
				return array($field->getName(), 'minlen', $field->getMinLen());

			// Check if data type is correct
			if(! $field->checkDataType() && $field->getCurrentLen() > 0)
				return array($field->getName(), 'datatype', $field->getDataType());
		}

		return true;
	}
}
